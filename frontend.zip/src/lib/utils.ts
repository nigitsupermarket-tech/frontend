import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

// ─── Tailwind class merger ────────────────────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Currency formatting (₦ Naira) ───────────────────────────────────────────
export function formatCurrency(amount: number, currency = "NGN"): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatPrice(amount: number): string {
  return `₦${amount.toLocaleString("en-NG")}`;
}

// ─── Scale/weight quantity formatting ────────────────────────────────────────
// Every quantity picker in the app was previously formatted with a flat
// `.toFixed(1)` or `.toFixed(2)` regardless of the product's own
// scaleStep — so a product configured with a fine step like 0.005 (kg)
// would round its displayed quantity to the nearest 0.1 or 0.01, even
// though the actual quantity sold (and the price charged for it, which
// is computed off the real, unrounded value) was more precise than the
// number shown. e.g. a 0.075kg sale would render as "0.1 kg" on the POS
// cart line while the price correctly reflected 0.075kg — same number,
// two different displayed precisions for the same sale.
//
// Client requirement: always show a COMPULSORY minimum of 3 decimals —
// "0.380", never "0.38", and never trimmed or collapsed to a bare
// integer ("2.000", not "2"). If the product's own scaleStep needs even
// finer precision than that (e.g. 0.0005), that wins instead — 3 is a
// floor, not a ceiling.
export function scaleQtyDecimals(step?: number | null): number {
  if (!step || step <= 0) return 3; // no step available — 3-decimal floor
  const s = step.toString();
  const dotIdx = s.indexOf(".");
  const stepDecimals = dotIdx === -1 ? 0 : s.length - dotIdx - 1;
  const decimals = Math.max(3, stepDecimals);
  return Math.min(decimals, 4); // sane ceiling — a scale isn't THAT precise
}

export function formatScaleQty(qty: number, step?: number | null): string {
  return qty.toFixed(scaleQtyDecimals(step));
}

// ─── Abbreviated currency (for dashboard/stat cards where full figures
// would overflow or look cluttered, e.g. ₦8,481,585 → ₦8.48M) ───────────────
// Keeps 2 sig-figs after the decimal for readability, drops trailing ".00".
export function formatPriceCompact(amount: number): string {
  const abs = Math.abs(amount);
  const sign = amount < 0 ? "-" : "";

  const abbreviate = (value: number, suffix: string) => {
    const str = value.toFixed(2).replace(/\.?0+$/, "");
    return `${sign}₦${str}${suffix}`;
  };

  if (abs >= 1_000_000_000) return abbreviate(abs / 1_000_000_000, "B");
  if (abs >= 1_000_000) return abbreviate(abs / 1_000_000, "M");
  if (abs >= 100_000) return abbreviate(abs / 1_000, "K");
  // Below ₦100K, the full figure is short enough to just show as-is.
  return formatPrice(amount);
}

// ─── Date formatting ─────────────────────────────────────────────────────────
export function formatDate(
  dateStr: string | Date,
  options?: Intl.DateTimeFormatOptions,
): string {
  return new Intl.DateTimeFormat("en-NG", {
    day: "numeric",
    month: "short",
    year: "numeric",
    ...options,
  }).format(new Date(dateStr));
}

export function formatDateTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("en-NG", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function timeAgo(dateStr: string | Date): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  const intervals = [
    { label: "year", seconds: 31536000 },
    { label: "month", seconds: 2592000 },
    { label: "week", seconds: 604800 },
    { label: "day", seconds: 86400 },
    { label: "hour", seconds: 3600 },
    { label: "minute", seconds: 60 },
  ];
  for (const { label, seconds: s } of intervals) {
    const count = Math.floor(seconds / s);
    if (count >= 1) return `${count} ${label}${count !== 1 ? "s" : ""} ago`;
  }
  return "just now";
}

export function getRelativeTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return "just now";
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? "s" : ""} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  return formatDate(d);
}

// ─── Slug generation ─────────────────────────────────────────────────────────
export function generateSlug(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

// ─── SKU generation ───────────────────────────────────────────────────────────
// Produces a SKU like: CHKNOOD-842F3 from "Chicken Noodles"
// Format: up to 8 chars of uppercased initials/letters + dash + 5 random hex chars
export function generateSKU(productName: string): string {
  if (!productName.trim()) return "";
  // Take up to first 3 words, grab first 3 letters each, uppercase
  const words = productName.trim().split(/\s+/).slice(0, 3);
  const prefix = words
    .map((w) =>
      w
        .replace(/[^a-zA-Z0-9]/g, "")
        .toUpperCase()
        .slice(0, 3),
    )
    .join("")
    .slice(0, 8);
  // 5-char random hex suffix
  const suffix = Math.floor(Math.random() * 0xfffff)
    .toString(16)
    .toUpperCase()
    .padStart(5, "0");
  return `${prefix}-${suffix}`;
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

export function titleCase(str: string): string {
  return str.replace(/\b\w/g, (char) => char.toUpperCase());
}

export function truncate(text: string, length: number): string {
  if (text.length <= length) return text;
  return text.substring(0, length).trim() + "...";
}

// ─── Number helpers ──────────────────────────────────────────────────────────
export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

export function clampNumber(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

// ─── Discount helpers ────────────────────────────────────────────────────────
export function calculateDiscountPercent(
  original: number,
  sale: number,
): number {
  if (original <= 0) return 0;
  return Math.round(((original - sale) / original) * 100);
}

export function calculateDiscountPercentage(
  originalPrice: number,
  discountedPrice: number,
): number {
  if (originalPrice <= 0) return 0;
  return Math.round(((originalPrice - discountedPrice) / originalPrice) * 100);
}

// ─── Order status display ────────────────────────────────────────────────────
export const ORDER_STATUS_LABELS: Record<string, string> = {
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  PROCESSING: "Processing",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
  REFUNDED: "Refunded",
};

export const ORDER_STATUS_COLORS: Record<string, string> = {
  PENDING: "bg-yellow-100 text-yellow-800",
  CONFIRMED: "bg-blue-100 text-blue-800",
  PROCESSING: "bg-purple-100 text-purple-800",
  SHIPPED: "bg-indigo-100 text-indigo-800",
  DELIVERED: "bg-green-100 text-green-800",
  CANCELLED: "bg-red-100 text-red-800",
  REFUNDED: "bg-gray-100 text-gray-800",
};

export const PAYMENT_STATUS_COLORS: Record<string, string> = {
  PENDING: "bg-yellow-100 text-yellow-800",
  PAID: "bg-green-100 text-green-800",
  FAILED: "bg-red-100 text-red-800",
  REFUNDED: "bg-gray-100 text-gray-800",
};

// ─── Nigerian states ─────────────────────────────────────────────────────────
export const NIGERIAN_STATES = [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "FCT - Abuja",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
] as const;

export type NigerianState = (typeof NIGERIAN_STATES)[number];

// ─── Weight calculation ──────────────────────────────────────────────────────
export function calculateTotalWeight(
  items: Array<{ weight?: number | null; quantity: number }>,
): number {
  return items.reduce((total, item) => {
    const itemWeight = item.weight || 0;
    return total + itemWeight * item.quantity;
  }, 0);
}

// ─── File helpers ────────────────────────────────────────────────────────────
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}

// ─── URL builder for product images ──────────────────────────────────────────
export function getProductImage(images: string[], index = 0): string {
  return images?.[index] || "/images/placeholder-product.svg";
}

// ─── Validation helpers ──────────────────────────────────────────────────────
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function isValidNigerianPhone(phone: string): boolean {
  // Accepts formats: +234XXXXXXXXXX, 234XXXXXXXXXX, 0XXXXXXXXXX
  const phoneRegex = /^(\+?234|0)[789]\d{9}$/;
  return phoneRegex.test(phone.replace(/\s/g, ""));
}

export function formatNigerianPhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, "");

  if (cleaned.startsWith("234")) {
    return (
      "+234 " +
      cleaned.slice(3, 6) +
      " " +
      cleaned.slice(6, 9) +
      " " +
      cleaned.slice(9)
    );
  } else if (cleaned.startsWith("0")) {
    return (
      cleaned.slice(0, 4) + " " + cleaned.slice(4, 7) + " " + cleaned.slice(7)
    );
  }

  return phone;
}

// ─── Random string generator ─────────────────────────────────────────────────
export function generateRandomString(length: number = 10): string {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}

// ─── Object helpers ──────────────────────────────────────────────────────────
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

// ─── Function helpers ────────────────────────────────────────────────────────
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number,
): T {
  let timer: ReturnType<typeof setTimeout>;
  return ((...args: unknown[]) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  }) as T;
}

export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number,
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  return function executedFunction(...args: Parameters<T>) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

// ─── Array helpers ───────────────────────────────────────────────────────────
export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce(
    (result, item) => {
      const groupKey = String(item[key]);
      if (!result[groupKey]) {
        result[groupKey] = [];
      }
      result[groupKey].push(item);
      return result;
    },
    {} as Record<string, T[]>,
  );
}

export function removeDuplicates<T>(array: T[], key?: keyof T): T[] {
  if (key) {
    const seen = new Set();
    return array.filter((item) => {
      const k = item[key];
      return seen.has(k) ? false : seen.add(k);
    });
  }
  return Array.from(new Set(array));
}

// ─── Pagination helpers ──────────────────────────────────────────────────────
export function getPaginationInfo(page: number, limit: number, total: number) {
  const totalPages = Math.ceil(total / limit);
  const hasMore = page < totalPages;
  const hasPrevious = page > 1;
  const startIndex = (page - 1) * limit + 1;
  const endIndex = Math.min(page * limit, total);

  return {
    page,
    limit,
    total,
    totalPages,
    hasMore,
    hasPrevious,
    startIndex,
    endIndex,
  };
}
