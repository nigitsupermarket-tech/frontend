"use client";
// frontend/src/components/admin/sidebar.tsx
// Role-aware sidebar:
//   ADMIN   — everything
//   MANAGER — everything except ADMIN-only areas; user management scoped to
//             roles below MANAGER (see backend/src/utils/roleHierarchy.ts)
//   STAFF   — POS, products, orders, inventory, and user management scoped
//             to roles below STAFF (ACCOUNTANT/SALES/CUSTOMER) — no POS
//             sessions, no settings
//   SALES   — POS, orders, customers (no user mgmt), marketing, analytics

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  Mail,
  Truck,
  Star,
  BookOpen,
  ChevronDown,
  ChevronRight,
  ShoppingBag,
  X,
  Monitor,
  Tag,
  Store,
  TrendingUp,
  Activity,
  Inbox,
  Zap,
  CheckCircle,
  ClipboardCheck,
  FileText,
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/components/admin/sidebar-context";
import { useAuthStore } from "@/store/authStore";
import { apiGet } from "@/lib/api";

interface NavItem {
  label: string;
  href?: string;
  icon: React.ElementType;
  badge?: string | number;
  children?: { label: string; href: string }[];
  roles?: string[];
}

const ALL_NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },

  {
    label: "Point of Sale",
    icon: Monitor,
    roles: ["ADMIN", "STAFF", "SALES", "MANAGER"],
    children: [
      { label: "🖥️ Open POS", href: "/admin/pos" },
      { label: "POS Orders", href: "/admin/pos/orders" },
      // POS Sessions: ADMIN only — filtered in processedItems below
      { label: "POS Sessions", href: "/admin/pos/sessions" },
      // Void Requests: ADMIN only — filtered in processedItems below
      { label: "Void Requests", href: "/admin/pos/void-requests" },
    ],
  },

  {
    label: "Products",
    icon: Package,
    roles: ["ADMIN", "STAFF", "SALES", "MANAGER"],
    children: [
      { label: "All Products", href: "/admin/products" },
      { label: "Add Product", href: "/admin/products/new" },
      { label: "Categories", href: "/admin/categories" },
      { label: "Brands", href: "/admin/brands" },
      { label: "Inventory", href: "/admin/inventory" },
      { label: "Promotions", href: "/admin/promotions" },
    ],
  },

  {
    label: "Promotions",
    href: "/admin/promotions",
    icon: Tag,
    roles: ["SALES"],
  },

  {
    label: "Online Orders",
    icon: ShoppingCart,
    roles: ["ADMIN", "STAFF", "SALES", "MANAGER"],
    children: [{ label: "All Orders", href: "/admin/orders" }],
  },

  {
    // Customers: STAFF sees only All Customers; SALES same; ADMIN sees both
    label: "Customers",
    icon: Users,
    roles: ["ADMIN", "STAFF", "SALES", "MANAGER"],
    children: [
      { label: "All Customers", href: "/admin/customers" },
      { label: "User Management", href: "/admin/users" },
    ],
  },

  {
    // Stock Approvals — ADMIN only, full stop. Manager and Accountant no
    // longer get a read-only view either; the page itself also redirects
    // them away if they hit the URL directly (see stock-approvals/page.tsx).
    label: "Stock Approvals",
    href: "/admin/stock-approvals",
    icon: ClipboardCheck,
    roles: ["ADMIN"],
  },

  {
    // Reports — every staff-side role can generate a report; SALES/STAFF
    // only ever see their own activity (enforced server-side), while
    // ADMIN/MANAGER/ACCOUNTANT can pull org-wide or per-user reports.
    label: "Reports",
    href: "/admin/reports",
    icon: FileText,
  },

  {
    label: "Reviews",
    href: "/admin/reviews",
    icon: Star,
    roles: ["ADMIN", "STAFF", "MANAGER"],
  },

  {
    label: "Inbox",
    icon: Inbox,
    roles: ["ADMIN", "STAFF", "MANAGER"],
    children: [
      { label: "Contact Messages", href: "/admin/inbox/contacts" },
      { label: "Subscribers", href: "/admin/inbox/subscribers" },
    ],
  },

  {
    label: "Marketing",
    icon: Mail,
    roles: ["ADMIN", "STAFF", "SALES", "MANAGER"],
    children: [
      { label: "Email Campaigns", href: "/admin/marketing/emails" },
      { label: "SMS Campaigns", href: "/admin/marketing/sms" },
      { label: "Abandoned Carts", href: "/admin/marketing/abandoned-carts" },
      { label: "Discounts & Coupons", href: "/admin/discounts" },
    ],
  },

  {
    label: "Shipping",
    icon: Truck,
    roles: ["ADMIN", "STAFF", "MANAGER"],
    children: [
      { label: "Overview", href: "/admin/shipping" },
      { label: "Ready to Ship", href: "/admin/shipping/ready" },
      { label: "All Shipments", href: "/admin/shipping/shipments" },
      { label: "Shipping Zones", href: "/admin/shipping/zones" },
      { label: "Delivery Methods", href: "/admin/shipping/methods" },
    ],
  },

  {
    label: "Analytics",
    href: "/admin/analytics",
    icon: BarChart3,
    roles: ["ADMIN", "ACCOUNTANT"],
  },
  {
    label: "Activity Log",
    href: "/admin/activities",
    icon: Activity,
    roles: ["ADMIN"],
  },
  {
    label: "Sales Analytics",
    href: "/admin/analytics",
    icon: TrendingUp,
    roles: ["SALES"],
  },

  {
    label: "Blog",
    icon: BookOpen,
    roles: ["ADMIN", "STAFF", "MANAGER"],
    children: [
      { label: "All Posts", href: "/admin/blog" },
      { label: "New Post", href: "/admin/blog/new" },
    ],
  },

  {
    label: "Settings",
    icon: Settings,
    roles: ["ADMIN"],
    children: [
      { label: "General", href: "/admin/settings" },
      { label: "Pages", href: "/admin/settings/pages" },
      { label: "Site Identity", href: "/admin/settings/site" },
      { label: "Email Config", href: "/admin/settings/email" },
      { label: "SMS Config", href: "/admin/settings/sms" },
    ],
  },
];

function NavItemComponent({
  item,
  onNavigate,
}: {
  item: NavItem;
  onNavigate?: () => void;
}) {
  const pathname = usePathname();

  const isActive = item.href
    ? pathname === item.href
    : item.children?.some(
        (c) => pathname === c.href || pathname.startsWith(c.href + "/"),
      );

  const [expanded, setExpanded] = useState(isActive || false);
  const isPOS = item.label === "Point of Sale";

  if (item.children) {
    return (
      <div>
        <button
          onClick={() => setExpanded(!expanded)}
          className={cn(
            "w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
            isPOS
              ? isActive
                ? "bg-amber-100 text-amber-800"
                : "text-amber-700 hover:bg-amber-50"
              : isActive
                ? "bg-green-50 text-green-700"
                : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
          )}
        >
          <div className="flex items-center gap-3">
            <item.icon className="w-4 h-4 shrink-0" />
            {item.label}
          </div>
          {expanded ? (
            <ChevronDown className="w-3.5 h-3.5" />
          ) : (
            <ChevronRight className="w-3.5 h-3.5" />
          )}
        </button>
        {expanded && (
          <div className="mt-1 ml-7 space-y-0.5">
            {item.children.map(({ label, href }) => (
              <Link
                key={href}
                href={href}
                onClick={onNavigate}
                className={cn(
                  "block px-3 py-2 rounded-lg text-sm transition-colors",
                  pathname === href || pathname.startsWith(href + "/")
                    ? "bg-green-50 text-green-700 font-medium"
                    : "text-gray-500 hover:text-gray-900 hover:bg-gray-50",
                )}
              >
                {label}
              </Link>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <Link
      href={item.href!}
      onClick={onNavigate}
      className={cn(
        "flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
        isActive
          ? "bg-green-50 text-green-700"
          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
      )}
    >
      <div className="flex items-center gap-3">
        <item.icon className="w-4 h-4 shrink-0" />
        {item.label}
      </div>
      {item.badge ? (
        <span className="px-1.5 py-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] text-center">
          {item.badge}
        </span>
      ) : null}
    </Link>
  );
}

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const { user } = useAuthStore();
  const role = user?.role || "STAFF";
  const [pendingCount, setPendingCount] = useState(0);
  const [pendingVoidCount, setPendingVoidCount] = useState(0);

  // Load pending stock approval count — Admin only now sees the queue at all.
  const fetchPendingCount = () => {
    if (role !== "ADMIN") return;
    apiGet<any>("/stock-approvals/pending-count")
      .then((r) => setPendingCount(r.data?.count || 0))
      .catch(() => {});
  };
  const fetchPendingVoidCount = () => {
    if (role !== "ADMIN") return;
    apiGet<any>("/pos/void-requests/pending-count")
      .then((r) => setPendingVoidCount(r.data?.count || 0))
      .catch(() => {});
  };

  useEffect(() => {
    fetchPendingCount();
    fetchPendingVoidCount();
  }, [role]);

  // These badges used to only fetch once on mount — approving/rejecting a
  // request on the Stock Approvals or Void Requests page updated that
  // page's own list immediately, but the sidebar (a persistent layout
  // component, not remounted on navigation) never found out, so the
  // badge count only ever changed on a full page reload. Two
  // complementary fixes: an instant same-tab refresh via a custom event
  // those pages dispatch right after a successful approve/reject/bulk
  // action (see stock-approvals/page.tsx and pos/void-requests/page.tsx),
  // plus a light poll as a safety net for changes made in another tab or
  // by another staff member's session.
  useEffect(() => {
    if (role !== "ADMIN") return;
    const onChange = () => {
      fetchPendingCount();
      fetchPendingVoidCount();
    };
    window.addEventListener("pending-counts:refresh", onChange);
    const interval = setInterval(onChange, 30_000);
    return () => {
      window.removeEventListener("pending-counts:refresh", onChange);
      clearInterval(interval);
    };
  }, [role]);

  // Filter by role
  let visibleItems = ALL_NAV_ITEMS.filter(
    (item) => !item.roles || item.roles.includes(role),
  );

  // Apply role-specific child filtering
  visibleItems = visibleItems.map((item) => {
    // Customers: only ADMIN/MANAGER/STAFF get "User Management" — they can
    // upgrade/demote customers within their own rank in the role hierarchy.
    // SALES never gets user management access.
    if (item.label === "Customers" && role === "SALES") {
      return {
        ...item,
        children: item.children?.filter((c) => c.label !== "User Management"),
      };
    }
    // POS Sessions: ADMIN and MANAGER only
    if (
      item.label === "Point of Sale" &&
      role !== "ADMIN" &&
      role !== "MANAGER"
    ) {
      return {
        ...item,
        children: item.children?.filter((c) => c.label !== "POS Sessions"),
      };
    }
    // Void Requests: ADMIN only — everyone else requests void approval from
    // an admin instead of seeing the review queue.
    if (item.label === "Point of Sale" && role !== "ADMIN") {
      return {
        ...item,
        children: item.children?.filter((c) => c.label !== "Void Requests"),
      };
    }
    // Surface the pending count right in the label so it's visible without
    // extra badge plumbing on child nav items.
    if (item.label === "Point of Sale" && role === "ADMIN" && pendingVoidCount > 0) {
      return {
        ...item,
        children: item.children?.map((c) =>
          c.label === "Void Requests"
            ? { ...c, label: `Void Requests (${pendingVoidCount > 99 ? "99+" : pendingVoidCount})` }
            : c,
        ),
      };
    }
    // Products: SALES cannot create new products — hide "Add Product"
    if (item.label === "Products" && role === "SALES") {
      return {
        ...item,
        children: item.children?.filter((c) => c.label !== "Add Product"),
      };
    }
    return item;
  });

  // Remove standalone Promotions item for SALES now that it's inside Products
  visibleItems = visibleItems.filter(
    (item) => !(item.label === "Promotions" && role === "SALES"),
  );

  // Inject pending badge on Stock Approvals
  visibleItems = visibleItems.map((item) => {
    if (item.label === "Stock Approvals" && pendingCount > 0) {
      return { ...item, badge: pendingCount > 99 ? "99+" : pendingCount };
    }
    return item;
  });

  return (
    <>
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {role === "MANAGER" && (
          <div className="px-3 py-1.5 mb-2 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-lg">
            Manager
          </div>
        )}
        {role === "SALES" && (
          <div className="px-3 py-1.5 mb-2 bg-blue-50 text-blue-700 text-xs font-semibold rounded-lg">
            Sales Manager
          </div>
        )}
        {role === "ACCOUNTANT" && (
          <div className="px-3 py-1.5 mb-2 bg-teal-50 text-teal-700 text-xs font-semibold rounded-lg">
            Accountant
          </div>
        )}
        {role === "STAFF" && (
          <div className="px-3 py-1.5 mb-2 bg-amber-50 text-amber-700 text-xs font-semibold rounded-lg">
            Staff
          </div>
        )}
        {visibleItems.map((item) => (
          <NavItemComponent
            key={item.label}
            item={item}
            onNavigate={onNavigate}
          />
        ))}
      </nav>
      <div className="p-3 border-t border-gray-100">
        <Link
          href="/"
          onClick={onNavigate}
          className="flex items-center gap-2 px-3 py-2 text-xs text-gray-500 hover:text-green-600 rounded-lg hover:bg-gray-50 transition-colors"
        >
          ← Back to store
        </Link>
      </div>
    </>
  );
}

function Logo() {
  return (
    <div className="p-5 border-b border-gray-100">
      <Link href="/admin/dashboard" className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center">
          <ShoppingBag className="w-4 h-4 text-white" />
        </div>
        <div>
          <p className="text-sm font-bold text-gray-900">NigitTriple</p>
          <p className="text-[11px] text-gray-400">Admin Panel</p>
        </div>
      </Link>
    </div>
  );
}

export function AdminSidebar() {
  const { isOpen, close } = useSidebar();
  return (
    <>
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-gray-100 shrink-0">
        <Logo />
        <SidebarContent />
      </aside>
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/40 transition-opacity duration-300 lg:hidden",
          isOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none",
        )}
        onClick={close}
      />
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex flex-col w-72 bg-white border-r border-gray-100 transition-transform duration-300 ease-in-out lg:hidden",
          isOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <Link
            href="/admin/dashboard"
            onClick={close}
            className="flex items-center gap-2.5"
          >
            <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">NigitTriple</p>
              <p className="text-[11px] text-gray-400">Admin Panel</p>
            </div>
          </Link>
          <button
            onClick={close}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <SidebarContent onNavigate={close} />
      </aside>
    </>
  );
}
