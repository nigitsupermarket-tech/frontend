"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  UserCog,
  Archive,
  Download,
  KeyRound,
  X,
  Copy,
  Wand2,
} from "lucide-react";
import { PasswordInput } from "@/components/shared/password-input";
import { passwordProblem, generatePassword, PASSWORD_HINT } from "@/lib/password";
import { User } from "@/types";
import { apiGet, apiPost, apiPut, apiDelete, getApiError } from "@/lib/api";
import { useToast } from "@/store/uiStore";
import { formatDate } from "@/lib/utils";
import { useAuthStore } from "@/store/authStore";
import {
  TableRowSkeleton,
  EmptyState,
} from "@/components/shared/loading-spinner";

const roleColors: Record<string, string> = {
  ADMIN: "bg-red-100 text-red-700",
  MANAGER: "bg-emerald-100 text-emerald-700",
  STAFF: "bg-purple-100 text-purple-700",
  SALES: "bg-blue-100 text-blue-700",
  ACCOUNTANT: "bg-teal-100 text-teal-700",
  CUSTOMER: "bg-gray-100 text-gray-600",
};

// Mirrors backend/src/utils/roleHierarchy.ts — lower number = more senior.
// Keep these in sync if the hierarchy ever changes.
const ROLE_RANK: Record<string, number> = {
  ADMIN: 0,
  MANAGER: 1,
  STAFF: 2,
  ACCOUNTANT: 3,
  SALES: 3,
  CUSTOMER: 4,
};
const ALL_ROLES = Object.keys(ROLE_RANK);

export default function AdminUsersPage() {
  const { user: currentUser } = useAuthStore();
  const currentRole = currentUser?.role || "";
  const currentRank = ROLE_RANK[currentRole] ?? 99;
  const isAdmin = currentRole === "ADMIN";

  // Roles this actor is allowed to see at all — peers and anything below
  // them in the hierarchy. Mirrors the backend's rolesAbove() exclusion.
  const visibleRoles = isAdmin
    ? ALL_ROLES
    : ALL_ROLES.filter((r) => ROLE_RANK[r] >= currentRank);

  // Roles this actor is allowed to ASSIGN to someone (strictly below their
  // own rank) — ADMIN can assign anything, including ADMIN itself.
  const assignableRoles = isAdmin
    ? ALL_ROLES
    : ALL_ROLES.filter((r) => ROLE_RANK[r] > currentRank);

  // Only ADMIN/MANAGER mint brand-new accounts — STAFF's capability is
  // promoting/demoting EXISTING customers (backend also enforces this).
  const canCreate = isAdmin || currentRole === "MANAGER";
  const canDelete = isAdmin;
  // Mirrors the backend rule: ADMIN may reset anyone but themselves;
  // MANAGER/STAFF only accounts strictly below their own rank.
  const canResetTarget = (target: User) =>
    target.id !== currentUser?.id &&
    (isAdmin || ROLE_RANK[target.role] > currentRank);
  const canEditTarget = (target: User) =>
    isAdmin || ROLE_RANK[target.role] > currentRank;

  const defaultNewRole =
    assignableRoles.find((r) => r !== "CUSTOMER") || assignableRoles[0] || "";

  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<User | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    role: defaultNewRole,
    password: "",
  });
  const [saving, setSaving] = useState(false);
  const toast = useToast();

  // ── Reset another user's password ──────────────────────────────────────
  const [resetTarget, setResetTarget] = useState<User | null>(null);
  const [resetMode, setResetMode] = useState<"set" | "link">("set");
  const [resetPassword, setResetPassword] = useState("");
  const [resetting, setResetting] = useState(false);

  const openReset = (u: User) => {
    setResetTarget(u);
    setResetMode("set");
    setResetPassword("");
  };

  const submitReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetTarget) return;
    if (resetMode === "set") {
      const problem = passwordProblem(resetPassword);
      if (problem) {
        toast(problem, "error");
        return;
      }
    }
    setResetting(true);
    try {
      const res = await apiPost<any>(`/users/${resetTarget.id}/reset-password`, {
        mode: resetMode,
        password: resetMode === "set" ? resetPassword : undefined,
      });
      toast(res.message || "Password reset", "success");
      setResetTarget(null);
      setResetPassword("");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setResetting(false);
    }
  };

  // ── Staff-tier table (everyone visible except plain customers) ──────────
  const fetchUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      // Fetch each visible non-customer role separately and merge, since the
      // API may not support comma-separated role values. Visibility itself
      // is also enforced server-side — this just avoids requesting roles we
      // already know we can't see.
      const roleQueries = visibleRoles.filter((r) => r !== "CUSTOMER");
      const results = await Promise.all(
        roleQueries.map((role) =>
          apiGet<any>("/users", { role, limit: "100" }),
        ),
      );
      const merged = results.flatMap((r) => r.data.users || []);
      const unique = merged.filter(
        (u, i, arr) => arr.findIndex((x) => x.id === u.id) === i,
      );
      setUsers(unique);
    } catch {
      toast("Failed to load users", "error");
    } finally {
      setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // ── User lookup (search any role by name/email, then change their role) ─
  const [customerSearch, setCustomerSearch] = useState("");
  const [customerResults, setCustomerResults] = useState<User[]>([]);
  const [searchingCustomers, setSearchingCustomers] = useState(false);
  const [searchedOnce, setSearchedOnce] = useState(false);

  const searchCustomers = async () => {
    if (!customerSearch.trim()) return;
    setSearchingCustomers(true);
    setSearchedOnce(true);
    try {
      const res = await apiGet<any>("/users", {
        // No role filter: search across every role. The backend still hides
        // roles more senior than the signed-in user.
        search: customerSearch.trim(),
        limit: "20",
      });
      setCustomerResults(res.data.users || []);
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setSearchingCustomers(false);
    }
  };

  // ── Archive of deleted users (ADMIN only) ───────────────────────────────
  const [showArchive, setShowArchive] = useState(false);
  const [archive, setArchive] = useState<any[]>([]);
  const [loadingArchive, setLoadingArchive] = useState(false);

  const fetchArchive = async () => {
    setLoadingArchive(true);
    try {
      const res = await apiGet<any>("/users/archived", { limit: "50" });
      setArchive(res.data.archivedUsers || []);
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setLoadingArchive(false);
    }
  };

  const toggleArchive = () => {
    const next = !showArchive;
    setShowArchive(next);
    if (next) fetchArchive();
  };

  const downloadSnapshot = async (id: string, email: string) => {
    try {
      const res = await apiGet<any>(`/users/archived/${id}`);
      const blob = new Blob([JSON.stringify(res.data.archivedUser, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `archived-user-${email}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      toast(getApiError(err), "error");
    }
  };

  const openNew = () => {
    setEditItem(null);
    setForm({
      name: "",
      email: "",
      phone: "",
      role: defaultNewRole,
      password: "",
    });
    setShowForm(true);
  };

  const openEdit = (u: User) => {
    if (!canEditTarget(u)) {
      toast("You don't have permission to modify this account", "error");
      return;
    }
    setEditItem(u);
    setForm({
      name: u.name,
      email: u.email,
      phone: u.phone || "",
      role: u.role,
      password: "",
    });
    setShowForm(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editItem) {
      const problem = passwordProblem(form.password);
      if (problem) {
        toast(problem, "error");
        return;
      }
    }
    setSaving(true);
    try {
      if (editItem) {
        await apiPut(`/users/${editItem.id}`, {
          name: form.name,
          phone: form.phone || undefined,
          role: form.role,
        });
        toast(
          form.role !== editItem.role
            ? `${editItem.name} is now ${form.role}`
            : "User updated",
          "success",
        );
        // Reflect the change immediately wherever this user is showing.
        setUsers((prev) =>
          prev
            .map((u) =>
              u.id === editItem.id
                ? { ...u, ...form, role: form.role as User["role"] }
                : u,
            )
            // If they were demoted to CUSTOMER (or promoted out of
            // visibility), drop them from the staff-tier table.
            .filter(
              (u) => visibleRoles.includes(u.role) && u.role !== "CUSTOMER",
            ),
        );
        // Keep the user in the search results, reflecting their new role.
        setCustomerResults((prev) =>
          prev.map((u) =>
            u.id === editItem.id
              ? { ...u, role: form.role as User["role"] }
              : u,
          ),
        );
      } else {
        await apiPost("/users", {
          name: form.name,
          email: form.email,
          phone: form.phone || undefined,
          role: form.role,
          password: form.password,
        });
        toast("User created", "success");
        fetchUsers();
      }
      setShowForm(false);
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (
      !confirm(
        `Remove "${name}"?\n\nA snapshot of their account (profile, addresses, reviews, order history) will be saved to the Archived users list first. Their past orders are kept.`,
      )
    )
      return;
    try {
      await apiDelete(`/users/${id}`);
      toast("User archived and removed", "success");
      setCustomerResults((prev) => prev.filter((u) => u.id !== id));
      fetchUsers();
      if (isAdmin && showArchive) fetchArchive();
    } catch (err) {
      toast(getApiError(err), "error");
    }
  };

  const inputCls =
    "w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-brand-500 transition-colors";

  const renderRoleOptions = () =>
    assignableRoles.map((r) => (
      <option key={r} value={r}>
        {r.charAt(0) + r.slice(1).toLowerCase()}
      </option>
    ));

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">User Management</h1>
          <p className="text-xs text-gray-400 mt-0.5">
            {isAdmin
              ? "Full access — all roles"
              : `Signed in as ${currentRole.charAt(0) + currentRole.slice(1).toLowerCase()} — you can only manage roles below your own`}
          </p>
        </div>
        {canCreate && (
          <button
            onClick={openNew}
            className="flex items-center gap-2 px-4 py-2.5 bg-brand-600 text-white text-sm font-medium rounded-xl hover:bg-brand-700 transition-colors"
          >
            <Plus className="w-4 h-4" /> Add User
          </button>
        )}
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h2 className="font-semibold text-gray-900 mb-4">
            {editItem ? `Edit ${editItem.name}` : "New Staff User"}
          </h2>
          <form onSubmit={handleSubmit} className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Full Name *
              </label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
                disabled={!!editItem}
                className={
                  inputCls + (editItem ? " bg-gray-50 text-gray-400" : "")
                }
                placeholder="Jane Doe"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Email *
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
                disabled={!!editItem}
                className={
                  inputCls + (editItem ? " bg-gray-50 text-gray-400" : "")
                }
                placeholder="jane@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Phone
              </label>
              <input
                type="tel"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                disabled={!!editItem}
                className={
                  inputCls + (editItem ? " bg-gray-50 text-gray-400" : "")
                }
                placeholder="+234..."
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Role *
              </label>
              <select
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value })}
                className={inputCls + " bg-white"}
              >
                {renderRoleOptions()}
              </select>
              {editItem && (
                <p className="text-[11px] text-gray-400 mt-1">
                  Only roles below your own are selectable.
                </p>
              )}
            </div>
            {!editItem && (
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">
                  Password *
                </label>
                <PasswordInput
                  value={form.password}
                  onChange={(e) =>
                    setForm({ ...form, password: e.target.value })
                  }
                  required
                  autoComplete="new-password"
                  className={inputCls}
                  placeholder="Min 8 characters"
                  minLength={8}
                />
                <p className="text-[11px] text-gray-400 mt-1">{PASSWORD_HINT}</p>
              </div>
            )}
            <div className="sm:col-span-2 flex gap-3">
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 bg-brand-600 text-white text-sm font-medium rounded-xl hover:bg-brand-700 disabled:opacity-60 transition-colors"
              >
                {saving ? "Saving…" : editItem ? "Update" : "Create"}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-5 py-2.5 border border-gray-200 text-sm font-medium rounded-xl hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ── User lookup — find any user (all roles) and change their role ── */}
      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <div className="flex items-center gap-2 mb-3">
          <UserCog className="w-4 h-4 text-gray-400" />
          <h2 className="font-semibold text-gray-900 text-sm">
            Find a user (any role)
          </h2>
        </div>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={customerSearch}
              onChange={(e) => setCustomerSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && searchCustomers()}
              placeholder="Search by name or email…"
              className={inputCls + " pl-9"}
            />
          </div>
          <button
            onClick={searchCustomers}
            disabled={searchingCustomers || !customerSearch.trim()}
            className="px-4 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-xl hover:bg-gray-800 disabled:opacity-50 transition-colors"
          >
            {searchingCustomers ? "Searching…" : "Search"}
          </button>
        </div>

        {searchedOnce && !searchingCustomers && (
          <div className="mt-4 divide-y divide-gray-50">
            {customerResults.length === 0 ? (
              <p className="text-xs text-gray-400 py-3">
                No matching users found.
              </p>
            ) : (
              customerResults.map((u) => (
                <div
                  key={u.id}
                  className="flex items-center justify-between py-2.5"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-xs font-bold text-brand-700 shrink-0">
                      {u.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">
                        {u.name}
                      </p>
                      <p className="text-xs text-gray-400">{u.email}</p>
                    </div>
                    <span
                      className={`ml-2 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        roleColors[u.role] || "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {u.role}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {canResetTarget(u) && (
                      <button
                        onClick={() => openReset(u)}
                        className="px-3 py-1.5 text-xs font-medium text-amber-700 bg-amber-50 rounded-lg hover:bg-amber-100 transition-colors"
                      >
                        Reset password
                      </button>
                    )}
                    <button
                      onClick={() => openEdit(u)}
                      disabled={!canEditTarget(u)}
                      title={
                        canEditTarget(u)
                          ? undefined
                          : "You can't modify this account"
                      }
                      className="px-3 py-1.5 text-xs font-medium text-brand-700 bg-brand-50 rounded-lg hover:bg-brand-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                    >
                      {u.role === "CUSTOMER" ? "Upgrade role" : "Edit role"}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* ── Archived (deleted) users — ADMIN only ─────────────────────── */}
      {isAdmin && (
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <button
            onClick={toggleArchive}
            className="flex items-center gap-2 w-full text-left"
          >
            <Archive className="w-4 h-4 text-gray-400" />
            <h2 className="font-semibold text-gray-900 text-sm">
              Archived users
            </h2>
            <span className="text-xs text-gray-400 ml-auto">
              {showArchive ? "Hide" : "Show"}
            </span>
          </button>
          {showArchive && (
            <div className="mt-3 divide-y divide-gray-50">
              {loadingArchive ? (
                <p className="text-xs text-gray-400 py-3">Loading…</p>
              ) : archive.length === 0 ? (
                <p className="text-xs text-gray-400 py-3">
                  No deleted users yet.
                </p>
              ) : (
                archive.map((a) => (
                  <div
                    key={a.id}
                    className="flex items-center justify-between py-2.5 gap-3"
                  >
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">
                        {a.name}{" "}
                        <span
                          className={`ml-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            roleColors[a.role] || "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {a.role}
                        </span>
                      </p>
                      <p className="text-xs text-gray-400 truncate">
                        {a.email} · deleted {formatDate(a.deletedAt)}
                        {a.deletedByName ? ` by ${a.deletedByName}` : ""} ·{" "}
                        {(a.counts?.orders ?? 0) +
                          (a.counts?.posOrdersProcessed ?? 0)}{" "}
                        orders kept
                      </p>
                    </div>
                    <button
                      onClick={() => downloadSnapshot(a.id, a.email)}
                      className="shrink-0 flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" /> Snapshot
                    </button>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* ── Staff-tier accounts (peers and below, per role hierarchy) ──── */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-50 bg-gray-50/50">
              {["User", "Role", "Phone", "Joined", ""].map((h) => (
                <th
                  key={h}
                  className="text-left px-4 py-3 font-medium text-gray-500 text-xs uppercase tracking-wide"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRowSkeleton key={i} cols={5} />
              ))
            ) : users.length === 0 ? (
              <tr>
                <td colSpan={5}>
                  <EmptyState title="No staff users found" />
                </td>
              </tr>
            ) : (
              users.map((u) => (
                <tr
                  key={u.id}
                  className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-xs font-bold text-brand-700 shrink-0">
                        {u.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{u.name}</p>
                        <p className="text-xs text-gray-400">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                        roleColors[u.role] || "bg-gray-100 text-gray-600"
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs">
                    {u.phone || "—"}
                  </td>
                  <td className="px-4 py-3 text-gray-400 text-xs">
                    {formatDate(u.createdAt)}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      {canEditTarget(u) && (
                        <button
                          onClick={() => openEdit(u)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-brand-600 hover:bg-brand-50 transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      )}
                      {canResetTarget(u) && (
                        <button
                          onClick={() => openReset(u)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title="Reset password"
                        >
                          <KeyRound className="w-4 h-4" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => handleDelete(u.id, u.name)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ── Reset password dialog ─────────────────────────────────────── */}
      {resetTarget && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
          <form
            onSubmit={submitReset}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 space-y-4"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="font-bold text-gray-900">Reset password</h2>
                <p className="text-sm text-gray-500 truncate">
                  {resetTarget.name} · {resetTarget.email}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setResetTarget(null)}
                aria-label="Close"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              {(
                [
                  ["set", "Set a new password"],
                  ["link", "Email a reset link"],
                ] as const
              ).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setResetMode(value)}
                  className={`px-3 py-2 rounded-xl border font-medium transition-colors ${
                    resetMode === value
                      ? "border-brand-500 bg-brand-50 text-brand-700"
                      : "border-gray-200 text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {resetMode === "set" ? (
              <div className="space-y-2">
                <label className="block text-xs font-medium text-gray-600">
                  New password
                </label>
                <PasswordInput
                  value={resetPassword}
                  onChange={(e) => setResetPassword(e.target.value)}
                  autoComplete="new-password"
                  className={inputCls}
                  placeholder="New password"
                  autoFocus
                />
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setResetPassword(generatePassword())}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
                  >
                    <Wand2 className="w-3.5 h-3.5" /> Generate
                  </button>
                  <button
                    type="button"
                    disabled={!resetPassword}
                    onClick={() => {
                      navigator.clipboard?.writeText(resetPassword);
                      toast("Password copied", "success");
                    }}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-40"
                  >
                    <Copy className="w-3.5 h-3.5" /> Copy
                  </button>
                </div>
                <p className="text-[11px] text-gray-400">{PASSWORD_HINT}</p>
                <p className="text-[11px] text-amber-600">
                  Share it with the user securely — it is not shown again after
                  you save. They are signed out of every device.
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-600">
                We will email {resetTarget.email} a link, valid for 1 hour, to
                choose their own new password. Their current password keeps
                working until they use it.
              </p>
            )}

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setResetTarget(null)}
                className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-sm text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={resetting}
                className="flex-1 px-4 py-2.5 rounded-xl bg-brand-600 text-white text-sm font-semibold hover:bg-brand-700 disabled:opacity-60"
              >
                {resetting
                  ? "Working…"
                  : resetMode === "set"
                    ? "Set password"
                    : "Send link"}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
