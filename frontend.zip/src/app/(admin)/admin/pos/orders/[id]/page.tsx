"use client";

// frontend/src/app/(admin)/admin/pos/orders/[id]/page.tsx
//
// This used to be an in-page modal rendered via createPortal. That's since
// been replaced with this dedicated route as a general structural
// improvement (a modal on the list page vs. a real, linkable/bookmarkable
// detail page) — but it turned out NOT to be the cause of "View" getting
// stuck on "Loading…" forever, since createPortal is a first-class,
// React-tracked way to render elsewhere in the document. The actual cause
// was the print engine appending a plain, non-React <iframe> into the live
// document — see lib/posReceipt.ts's openPrintWindow() for the full
// explanation and the fix (printing into a separate window instead).
//
// DYNAMIC ORDER-TYPE HANDLING: an order ID landing on this page isn't
// guaranteed to be a POS order — POSOrder and the online Order model are
// two entirely separate Mongo collections with different shapes, and a
// stale link, a bookmark, or someone pasting the wrong ID can point here
// with an online order's ID instead. Previously this just called
// /pos/orders/:id and had no fallback: a 404 there showed an error, but
// there was nothing to catch a genuine online order's ID other than that
// error. Now it checks POS first, and if that specific ID isn't a POS
// order, it transparently tries the online-order endpoint and redirects to
// the existing online order detail page if that's what the ID actually is
// — so this route "recognizes" either kind of order instead of assuming.
//
// HARD TIMEOUT: previously a stuck backend request (or MongoDB query) could
// leave this page spinning on "Loading…" forever, since nothing bounded how
// long the fetch was allowed to hang before surfacing an error. A 12s
// client-side timeout now guarantees the spinner always resolves to either
// data or a clear, actionable error — never an infinite spinner.
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import axios from "axios";
import {
  ArrowLeft,
  Loader2,
  Printer,
  Download,
  XCircle,
  RefreshCcw,
  ShieldAlert,
  Clock,
  CheckCircle2,
  X,
} from "lucide-react";
import { apiGet, apiPost, apiPut, getApiError } from "@/lib/api";
import { formatPrice } from "@/lib/utils";
import { PageLoader, ErrorState } from "@/components/shared/loading-spinner";
import { useToast } from "@/store/uiStore";
import { useAuthStore } from "@/store/authStore";
import {
  type POSOrder,
  printBothReceipts,
  downloadPosReceiptPdf,
  buildBothReceiptsHtml,
} from "@/lib/posReceipt";

const FETCH_TIMEOUT_MS = 12_000;

interface VoidRequestStatus {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  reason: string;
  reviewNote?: string;
  reviewedByName?: string;
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(
        () => reject(new Error("TIMEOUT: request took too long")),
        ms,
      ),
    ),
  ]);
}

export default function POSOrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const toast = useToast();
  const { user } = useAuthStore();
  const isAdmin = user?.role === "ADMIN";

  const [order, setOrder] = useState<POSOrder | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [printing, setPrinting] = useState(false);
  // Preview-before-print modal — same idea as the live checkout page's
  // "Payment Successful" screen and the orders list's own preview: see
  // the actual receipt (with the copy labels, cut-line, everything the
  // real print job renders) before it goes to a printer.
  const [showPreview, setShowPreview] = useState(false);
  const [voidReason, setVoidReason] = useState("");
  const [voiding, setVoiding] = useState(false);
  const [voidRequest, setVoidRequest] = useState<VoidRequestStatus | null>(null);
  const [loadingVoidRequest, setLoadingVoidRequest] = useState(true);

  const loadOrder = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await withTimeout(
        apiGet<any>(`/pos/orders/${id}`),
        FETCH_TIMEOUT_MS,
      );
      setOrder(res.data.order);
    } catch (err: any) {
      const is404 =
        axios.isAxiosError(err) && err.response?.status === 404;

      if (is404) {
        // Not a POS order — check whether it's actually an online order
        // before giving up, and hand off to that page if so.
        try {
          await withTimeout(apiGet<any>(`/orders/${id}`), FETCH_TIMEOUT_MS);
          router.replace(`/admin/orders/${id}`);
          return; // don't fall through to setIsLoading(false) below —
          // we're navigating away, not staying on this page.
        } catch {
          // Genuinely doesn't exist in either collection.
          setError("This order was not found as a POS order or an online order.");
        }
      } else if (err?.message?.startsWith("TIMEOUT")) {
        console.error("POS order fetch timed out:", { id, err });
        setError(
          "The server took too long to respond. Check your connection and try again.",
        );
      } else {
        console.error("POS order fetch failed:", { id, err });
        setError(getApiError(err));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const loadVoidRequestStatus = async () => {
    setLoadingVoidRequest(true);
    try {
      const res = await apiGet<any>(`/pos/orders/${id}/void-request`);
      setVoidRequest(res.data?.request || null);
    } catch {
      // Non-fatal — the void/request UI just falls back to its default state.
    } finally {
      setLoadingVoidRequest(false);
    }
  };

  useEffect(() => {
    if (id) {
      loadOrder();
      loadVoidRequestStatus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handlePrint = () => {
    if (!order || printing) return;
    setPrinting(true);
    printBothReceipts(
      order,
      () => setPrinting(false),
      (message) => toast(message, "error"),
    );
  };

  const handleDownload = () => {
    if (!order) return;
    downloadPosReceiptPdf(order, (message) => toast(message, "error"));
  };

  // Admin — voids the order directly and immediately.
  const handleVoid = async () => {
    if (!order) return;
    if (!voidReason.trim()) {
      toast("Please enter a reason for voiding", "error");
      return;
    }
    setVoiding(true);
    try {
      await apiPut(`/pos/orders/${order.id}/void`, { reason: voidReason });
      toast("Order voided and stock restored", "success");
      loadOrder();
      setVoidReason("");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setVoiding(false);
    }
  };

  // Non-admin — submits a request for an admin to approve instead of
  // voiding directly.
  const handleRequestVoid = async () => {
    if (!order) return;
    if (!voidReason.trim()) {
      toast("Please enter a reason for the admin to review", "error");
      return;
    }
    setVoiding(true);
    try {
      await apiPost(`/pos/orders/${order.id}/void-request`, {
        reason: voidReason,
      });
      toast("Request sent — an admin needs to approve this void", "success");
      setVoidReason("");
      loadVoidRequestStatus();
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setVoiding(false);
    }
  };

  if (isLoading) return <PageLoader />;
  if (error || !order)
    return (
      <div className="p-6 space-y-4">
        <ErrorState message={error || "Order not found"} />
        <div className="flex justify-center gap-3">
          <button
            type="button"
            onClick={loadOrder}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50"
          >
            <RefreshCcw className="w-4 h-4" /> Retry
          </button>
          <Link
            href="/admin/pos/orders"
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-50"
          >
            <ArrowLeft className="w-4 h-4" /> Back to POS Orders
          </Link>
        </div>
      </div>
    );

  return (
    <div className="p-6 max-w-3xl space-y-5">
      <div className="flex items-center gap-4">
        <Link
          href="/admin/pos/orders"
          className="p-2 rounded-lg border border-gray-200 text-gray-500 hover:text-gray-700"
        >
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-gray-900">
            {order.posOrderNumber}
          </h1>
          <p className="text-sm text-gray-500 font-mono">
            Receipt: {order.receiptNumber || "—"}
          </p>
        </div>
        <span
          className={`px-3 py-1 rounded-full text-sm font-medium ${
            order.status === "VOIDED"
              ? "bg-red-100 text-red-700"
              : order.status === "COMPLETED"
                ? "bg-green-100 text-green-700"
                : "bg-gray-100 text-gray-600"
          }`}
        >
          {order.status}
        </span>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 p-5 space-y-4">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="bg-gray-50 rounded p-3">
            <p className="text-xs text-gray-500">Date/Time</p>
            <p className="font-medium">
              {new Date(order.createdAt).toLocaleString("en-NG")}
            </p>
          </div>
          <div className="bg-gray-50 rounded p-3">
            <p className="text-xs text-gray-500">Staff</p>
            <p className="font-medium">{order.processedBy?.name || "—"}</p>
          </div>
          {order.customerName && (
            <div className="bg-gray-50 rounded p-3">
              <p className="text-xs text-gray-500">Customer</p>
              <p className="font-medium">{order.customerName}</p>
              {order.customerPhone && (
                <p className="text-xs text-gray-400">{order.customerPhone}</p>
              )}
            </div>
          )}
          <div className="bg-gray-50 rounded p-3">
            <p className="text-xs text-gray-500">Payment</p>
            <p className="font-medium">{order.paymentMethod}</p>
            {order.amountTendered !== undefined && (
              <p className="text-xs text-gray-400">
                Tendered: {formatPrice(order.amountTendered)}
              </p>
            )}
            {order.changeGiven !== undefined && order.changeGiven > 0 && (
              <p className="text-xs text-gray-400">
                Change: {formatPrice(order.changeGiven)}
              </p>
            )}
          </div>
        </div>

        {/* Items */}
        <div>
          <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2">
            Items
          </h4>
          <div className="divide-y divide-gray-100 border border-gray-200 rounded">
            {(order.items || []).map((item, i) => (
              <div
                key={item.id || i}
                className="flex items-center justify-between px-3 py-2 text-sm"
              >
                <div>
                  <p className="font-medium text-gray-900">
                    {item.productName}
                  </p>
                  <p className="text-xs text-gray-400">
                    {item.productSku}
                    {item.netWeight && ` · ${item.netWeight}`}
                    {item.discountApplied > 0 &&
                      ` · -${item.discountApplied}% disc.`}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{formatPrice(item.subtotal)}</p>
                  <p className="text-xs text-gray-400">
                    {item.scaleUnit
                      ? `${item.quantity % 1 === 0 ? item.quantity.toFixed(0) : item.quantity.toFixed(2)} ${item.scaleUnit} × ${formatPrice(item.unitPrice)}/${item.scaleUnit}`
                      : `${item.quantity} × ${formatPrice(item.unitPrice)}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Totals */}
        <div className="border-t pt-3 space-y-1.5 text-sm">
          <div className="flex justify-between text-gray-600">
            <span>Subtotal</span>
            <span>{formatPrice(order.subtotal)}</span>
          </div>
          {order.discountAmount > 0 && (
            <div className="flex justify-between text-green-700">
              <span>Discount</span>
              <span>-{formatPrice(order.discountAmount)}</span>
            </div>
          )}
          <div className="flex justify-between font-extrabold text-gray-900 text-base pt-1 border-t">
            <span>Total</span>
            <span>{formatPrice(order.total)}</span>
          </div>
        </div>

        {/* Void — ADMIN sees a direct void form. Every other role sees a
            "request approval" flow instead, with the current status of
            their most recent request (if any). */}
        {order.status === "COMPLETED" && !loadingVoidRequest && (
          <>
            {isAdmin ? (
              <div className="border border-red-200 rounded-lg p-3 bg-red-50">
                <p className="text-xs font-semibold text-red-700 mb-2">
                  Void this order (stock will be restored)
                </p>
                <input
                  type="text"
                  placeholder="Reason for voiding..."
                  value={voidReason}
                  onChange={(e) => setVoidReason(e.target.value)}
                  className="w-full border border-red-200 px-3 py-2 text-sm rounded focus:outline-none focus:border-red-400 mb-2"
                />
                <button
                  type="button"
                  onClick={handleVoid}
                  disabled={voiding || !voidReason.trim()}
                  className="w-full py-2 bg-red-600 text-white text-sm font-semibold rounded hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {voiding ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" /> Void Order
                    </>
                  )}
                </button>
              </div>
            ) : voidRequest?.status === "PENDING" ? (
              <div className="border border-amber-200 rounded-lg p-3 bg-amber-50 flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-amber-800">
                    Void request pending admin approval
                  </p>
                  <p className="text-amber-700 text-xs mt-0.5">
                    You requested to void this order: &ldquo;{voidRequest.reason}
                    &rdquo;. An admin needs to approve it before stock is
                    restored and the order is voided.
                  </p>
                </div>
              </div>
            ) : voidRequest?.status === "REJECTED" ? (
              <div className="border border-gray-200 rounded-lg p-3 bg-gray-50 space-y-2">
                <div className="flex items-start gap-2">
                  <XCircle className="w-4 h-4 text-gray-500 shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-semibold text-gray-700">
                      Your last void request was rejected
                    </p>
                    {voidRequest.reviewNote && (
                      <p className="text-gray-500 text-xs mt-0.5">
                        Admin note: &ldquo;{voidRequest.reviewNote}&rdquo;
                      </p>
                    )}
                  </div>
                </div>
                <p className="text-xs font-semibold text-gray-600">
                  You can submit a new request below.
                </p>
                <RequestVoidForm
                  voidReason={voidReason}
                  setVoidReason={setVoidReason}
                  voiding={voiding}
                  onSubmit={handleRequestVoid}
                />
              </div>
            ) : (
              <div className="border border-amber-200 rounded-lg p-3 bg-amber-50">
                <p className="text-xs font-semibold text-amber-800 mb-1 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  Only an admin can void an order
                </p>
                <p className="text-xs text-amber-700 mb-2">
                  You don&apos;t have permission to void orders. Submit a
                  request below and an admin will review it — stock is only
                  restored once they approve.
                </p>
                <RequestVoidForm
                  voidReason={voidReason}
                  setVoidReason={setVoidReason}
                  voiding={voiding}
                  onSubmit={handleRequestVoid}
                />
              </div>
            )}
          </>
        )}

        {/* An approved void request explains why a non-admin-facing order
            now shows as VOIDED, even though they never had direct access. */}
        {order.status === "VOIDED" && !isAdmin && voidRequest?.status === "APPROVED" && (
          <div className="border border-green-200 rounded-lg p-3 bg-green-50 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold text-green-800">
                Your void request was approved
              </p>
              <p className="text-green-700 text-xs mt-0.5">
                Approved by {voidRequest.reviewedByName || "an admin"}
                {voidRequest.reviewNote && (
                  <> — &ldquo;{voidRequest.reviewNote}&rdquo;</>
                )}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <button
          type="button"
          onClick={() => setShowPreview(true)}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 text-sm"
          title="Preview receipt before printing"
        >
          <Printer className="w-4 h-4" /> Preview & Print
        </button>
        <button
          type="button"
          onClick={handleDownload}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 text-sm"
          title="Downloads both copies as PDF files (customer + merchant)"
        >
          <Download className="w-4 h-4" /> Download (2 copies)
        </button>
      </div>

      {showPreview && order && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div>
                <h3 className="font-semibold text-gray-900">Receipt Preview</h3>
                <p className="text-xs text-gray-400">
                  {order.receiptNumber} — merchant + customer copy
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowPreview(false)}
                className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto bg-gray-50 p-3">
              <iframe
                title="Receipt preview"
                srcDoc={buildBothReceiptsHtml(order)}
                className="w-full bg-white rounded-lg border border-gray-200"
                style={{ height: "60vh" }}
              />
            </div>
            <div className="flex gap-2 px-5 py-4 border-t border-gray-100">
              <button
                type="button"
                onClick={handleDownload}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <Download className="w-4 h-4" /> Download PDF
              </button>
              <button
                type="button"
                disabled={printing}
                onClick={() => {
                  handlePrint();
                  setShowPreview(false);
                }}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-green-600 text-white text-sm font-medium hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                {printing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Printer className="w-4 h-4" />
                )}
                Print
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function RequestVoidForm({
  voidReason,
  setVoidReason,
  voiding,
  onSubmit,
}: {
  voidReason: string;
  setVoidReason: (v: string) => void;
  voiding: boolean;
  onSubmit: () => void;
}) {
  return (
    <>
      <input
        type="text"
        placeholder="Reason for the admin to review..."
        value={voidReason}
        onChange={(e) => setVoidReason(e.target.value)}
        className="w-full border border-amber-200 px-3 py-2 text-sm rounded focus:outline-none focus:border-amber-400 mb-2"
      />
      <button
        type="button"
        onClick={onSubmit}
        disabled={voiding || !voidReason.trim()}
        className="w-full py-2 bg-amber-600 text-white text-sm font-semibold rounded hover:bg-amber-700 disabled:opacity-50 flex items-center justify-center gap-2"
      >
        {voiding ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <>
            <ShieldAlert className="w-4 h-4" /> Request Void Approval
          </>
        )}
      </button>
    </>
  );
}

