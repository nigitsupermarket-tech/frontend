"use client";
// frontend/src/app/(admin)/admin/pos/page.tsx

import { useState, useEffect, useRef, useCallback } from "react";
import type { KeyboardEvent as ReactKeyboardEvent, PointerEvent as ReactPointerEvent } from "react";
import {
  Search,
  Barcode,
  Minus,
  Trash2,
  Printer,
  CreditCard,
  Banknote,
  ArrowRightLeft,
  CheckCircle,
  X,
  ShoppingCart,
  Receipt,
  Calculator,
  Tag,
  RotateCcw,
  Clock,
  Package,
  Loader2,
  ChevronDown,
  LogIn,
  LogOut,
  User,
  AlertCircle,
  DollarSign,
  Grid3x3,
  LayoutList,
  Camera,
  PauseCircle,
  PlayCircle,
} from "lucide-react";
import { apiGet, apiPost, apiPut, apiDelete, getApiError } from "@/lib/api";
import { useToast } from "@/store/uiStore";
import { formatPrice, formatScaleQty, getProductImage } from "@/lib/utils";
import { useAuthStore } from "@/store/authStore";
import { useDraftSync } from "@/hooks/useDraftSync";
import { useCatalogSync } from "@/hooks/useCatalogSync";
import { normalizeBarcode } from "@/lib/barcode";
import {
  lookupByBarcode,
  lookupBySku,
  lookupByScaleBarcode,
  isScaleBarcode,
  searchLocal,
  type ScaleBarcodeError,
} from "@/lib/posOfflineCache";
import { ScaleProvider, useScale } from "@/lib/scale/ScaleContext";
import ScalePanel from "@/components/admin/pos/ScalePanel";
import WeighModal from "@/components/admin/pos/WeighModal";
import { printBothReceipts } from "@/lib/posReceipt";

// ─── Types ────────────────────────────────────────────────────────────────────
interface ProductVariation {
  id: string;
  label: string;
  quantity: number;
  price: number;
  compareAtPrice?: number | null;
  barcode?: string | null;
  stockQuantity?: number | null; // null = shared stock, number = dedicated
  isDefault: boolean;
  isActive: boolean;
  sortOrder: number;
}
interface Product {
  id: string;
  name: string;
  sku: string;
  barcode?: string;
  price: number;
  stockQuantity: number;
  images: string[];
  trackInventory: boolean;
  netWeight?: string;
  unitsPerCarton?: number;
  category?: { name: string };
  brand?: { name: string };
  // Scalable product
  isScalable?: boolean;
  scaleUnit?: string;
  pricePerUnit?: number;
  minOrderQty?: number;
  maxOrderQty?: number;
  scaleStep?: number;
  scalePresets?: number[];
  scaleWareCode?: string;
  variations?: ProductVariation[];
}
interface CartItem {
  product: Product;
  quantity: number; // for scalable: float amount (e.g. 1.5kg); for a variation: PACK COUNT
  unitPrice: number; // for scalable: pricePerUnit; for fixed: product.price; for a variation: variation.price
  discount: number;
  variationId?: string; // set when this line is a specific product variation/preset
  variationLabel?: string;
}
interface Discount {
  id: string;
  code: string;
  type: "PERCENTAGE" | "FIXED_AMOUNT" | "FREE_SHIPPING";
  value: number;
  minOrderAmount?: number;
  maxDiscount?: number;
  name: string;
}
type PaymentMethod = "CASH" | "CARD" | "TRANSFER" | "SPLIT";
interface SplitPayment {
  method: "CASH" | "CARD" | "TRANSFER";
  amount: number;
}
interface CompletedOrder {
  posOrderNumber: string;
  items: CartItem[];
  subtotal: number;
  discountAmount: number;
  total: number;
  paymentMethod: PaymentMethod;
  amountTendered?: number;
  changeGiven?: number;
  splitPayments?: SplitPayment[];
  customerName?: string;
  customerPhone?: string;
  processedAt: Date;
  receiptNumber: string;
}
// A POS order that has been suspended (retrieved from the API)
interface SuspendedOrder {
  id: string;
  posOrderNumber: string;
  suspendedAt: string;
  suspendLabel?: string | null;
  customerName?: string | null;
  subtotal: number;
  total: number;
  items: {
    id: string;
    productId: string;
    productName: string;
    productSku: string;
    quantity: number;
    unitPrice: number;
    subtotal: number;
    discountApplied: number;
    barcode?: string | null;
    netWeight?: string | null;
    scaleUnit?: string | null;
    variationId?: string | null;
    variationLabel?: string | null;
  }[];
}
interface POSSession {
  id: string;
  staffId: string;
  openedAt: string;
  status: string;
  openingFloat: number;
  totalSales: number;
  totalOrders: number;
  cashSales: number;
  cardSales: number;
  transferSales: number;
}

// ─── Session Gate ─────────────────────────────────────────────────────────────
function SessionGate({ onOpen }: { onOpen: (session: POSSession) => void }) {
  const [openingFloat, setOpeningFloat] = useState("");
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const { user } = useAuthStore();

  const openSession = async () => {
    setLoading(true);
    try {
      const res = await apiPost<any>("/pos/sessions", {
        openingFloat: parseFloat(openingFloat) || 0,
      });
      onOpen(res.data.session);
      toast("POS session opened", "success");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <LogIn className="w-8 h-8 text-green-600" />
        </div>
        <h2 className="text-xl font-bold text-gray-900 mb-1">
          Open POS Session
        </h2>
        <p className="text-sm text-gray-500 mb-6">
          Welcome,{" "}
          <span className="font-semibold text-gray-700">{user?.name}</span>.
          <br />
          Enter your opening cash float to begin.
        </p>
        <div className="mb-5">
          <label className="block text-xs font-semibold text-gray-600 mb-1.5 text-left">
            Opening Float (₦)
          </label>
          <input
            type="number"
            min={0}
            value={openingFloat}
            onChange={(e) => setOpeningFloat(e.target.value)}
            placeholder="e.g. 50000"
            className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-xl font-bold text-center focus:outline-none focus:border-green-500"
            autoFocus
          />
        </div>
        <button
          onClick={openSession}
          disabled={loading}
          className="w-full bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2"
        >
          {loading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <LogIn className="w-5 h-5" />
          )}
          Open Session
        </button>
      </div>
    </div>
  );
}

// ─── Close Session Modal ──────────────────────────────────────────────────────
function CloseSessionModal({
  session,
  onClose,
  onClosed,
}: {
  session: POSSession;
  onClose: () => void;
  onClosed: () => void;
}) {
  const [closingFloat, setClosingFloat] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const expectedCash = session.openingFloat + session.cashSales;
  const variance = closingFloat
    ? parseFloat(closingFloat) - expectedCash
    : null;

  const closeSession = async () => {
    setLoading(true);
    try {
      await apiPut<any>(`/pos/sessions/${session.id}/close`, {
        closingFloat: parseFloat(closingFloat) || 0,
        notes,
      });
      toast("Session closed successfully", "success");
      onClosed();
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        <div className="bg-gray-900 text-white px-6 py-4 flex items-center justify-between">
          <h2 className="font-bold text-lg">Close POS Session</h2>
          <button onClick={onClose}>
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          {/* Session summary */}
          <div className="bg-gray-50 rounded-xl p-4 grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-xs text-gray-500">Total Orders</p>
              <p className="font-bold text-gray-900">{session.totalOrders}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Total Sales</p>
              <p className="font-bold text-gray-900">
                {formatPrice(session.totalSales)}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Cash Sales</p>
              <p className="font-semibold">{formatPrice(session.cashSales)}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Card/Transfer</p>
              <p className="font-semibold">
                {formatPrice(session.cardSales + session.transferSales)}
              </p>
            </div>
            <div className="col-span-2 border-t border-gray-200 pt-2">
              <p className="text-xs text-gray-500">Expected Cash in Drawer</p>
              <p className="font-bold text-green-700 text-lg">
                {formatPrice(expectedCash)}
              </p>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Actual Cash in Drawer (₦)
            </label>
            <input
              type="number"
              min={0}
              value={closingFloat}
              onChange={(e) => setClosingFloat(e.target.value)}
              placeholder={String(Math.round(expectedCash))}
              className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 text-lg font-bold focus:outline-none focus:border-green-500"
              autoFocus
            />
            {variance !== null && (
              <p
                className={`mt-1 text-xs font-semibold ${variance >= 0 ? "text-green-600" : "text-red-600"}`}
              >
                {variance >= 0
                  ? `Surplus: +${formatPrice(variance)}`
                  : `Shortage: ${formatPrice(Math.abs(variance))}`}
              </p>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">
              Notes (optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Any discrepancies or notes..."
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-gray-400 resize-none"
            />
          </div>

          <button
            onClick={closeSession}
            disabled={loading}
            className="w-full bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <LogOut className="w-5 h-5" />
            )}
            Close Session
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Cart Item Row ─────────────────────────────────────────────────────────────
function CartItemRow({
  item,
  onQtyChange,
  onDiscountChange,
  onRemove,
}: {
  item: CartItem;
  onQtyChange: (qty: number) => void;
  onDiscountChange: (d: number) => void;
  onRemove: () => void;
}) {
  const [showDiscount, setShowDiscount] = useState(false);

  // ── Variation (structured preset) line ──────────────────────────────────
  // `variation` may be undefined even when item.variationId is set — e.g.
  // right after resuming a suspended order, the cart is rebuilt from a
  // snapshot that doesn't include the full product.variations array. The
  // line should still render/behave as a variation line using the snapshot
  // (item.variationLabel, item.unitPrice, item.quantity as pack count).
  const variation = item.variationId
    ? item.product.variations?.find((v) => v.id === item.variationId)
    : undefined;
  const isVariationLine = !!item.variationId;

  const isScalable = !!item.product.isScalable;
  const unit = item.product.scaleUnit || "unit";
  const step = item.product.scaleStep ?? 0.1;
  // Preset-only: scaleStep = 0 — no +/- increment on the cashier screen,
  // quantity can only change by tapping one of the preset weight chips.
  const presetOnly = !isVariationLine && isScalable && step === 0;
  const minQty = item.product.minOrderQty || (presetOnly ? 0 : step);
  const roundStep = (v: number) =>
    parseFloat((Math.round(v / step) * step).toFixed(10));

  const handleDecrement = () => {
    if (isVariationLine) {
      if (item.quantity <= 1) {
        onRemove();
        return;
      }
      onQtyChange(item.quantity - 1);
      return;
    }
    if (presetOnly) return;
    if (isScalable) {
      const next = roundStep(item.quantity - step);
      if (next < minQty) {
        onRemove();
        return;
      }
      onQtyChange(next);
    } else {
      onQtyChange(item.quantity - 1);
    }
  };

  // NOTE: there is intentionally no increment handler. Quantity can only go
  // UP when the item is scanned again (barcode gun / camera → addToCart with
  // fromScan). The cashier can only step DOWN one at a time or delete the line.

  const qtyDisplay = isVariationLine
    ? `×${item.quantity}`
    : isScalable
      ? `${formatScaleQty(item.quantity, step)} ${unit}`
      : String(item.quantity);

  const lineTotal = item.unitPrice * item.quantity * (1 - item.discount / 100);

  return (
    <div className="px-4 py-3 hover:bg-gray-50">
      <div className="flex items-start gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-gray-900 line-clamp-1">
            {item.product.name}
          </p>
          {isVariationLine ? (
            <p className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 inline-block px-1 rounded mt-0.5">
              {item.variationLabel || variation?.label}
            </p>
          ) : (
            <p className="text-[10px] text-gray-400">
              {item.product.sku}
              {item.product.netWeight && ` · ${item.product.netWeight}`}
            </p>
          )}
          <div className="flex items-center gap-1 mt-0.5">
            <span className="text-xs text-gray-600">
              {isVariationLine
                ? `${formatPrice(item.unitPrice)}/pack`
                : isScalable
                  ? `${formatPrice(item.unitPrice)}/${unit}`
                  : formatPrice(item.unitPrice)}
            </span>
            {item.discount > 0 && (
              <span className="text-[10px] text-green-700 bg-green-100 px-1 rounded">
                -{item.discount}%
              </span>
            )}
          </div>
        </div>

        {/* Quantity / amount control */}
        <div className="flex flex-col items-center gap-1">
          {/* Scalable presets row (legacy raw-number presets only) */}
          {!isVariationLine &&
            isScalable &&
            (item.product.scalePresets?.length ?? 0) > 0 && (
              <div className="flex gap-1 flex-wrap justify-end max-w-[120px]">
                {(item.product.scalePresets || []).slice(0, 4).map((p) => (
                  <button
                    key={p}
                    // Presets may only lower the quantity — raising it is
                    // scan-only.
                    disabled={p > item.quantity}
                    onClick={() => onQtyChange(p)}
                    className={`text-[8px] font-bold px-1.5 py-0.5 rounded border transition-colors disabled:opacity-30 disabled:cursor-not-allowed ${
                      item.quantity === p
                        ? "bg-green-600 text-white border-green-600"
                        : "border-gray-300 text-gray-600 hover:border-green-500"
                    }`}
                  >
                    {p}
                    {unit}
                  </button>
                ))}
              </div>
            )}

          {presetOnly ? (
            // No +/- increment in preset-only mode — quantity can only be
            // changed by tapping a different preset chip above, or removed.
            <span className="text-center text-xs font-bold w-14 px-1 py-1 border border-gray-200 rounded bg-gray-50">
              {qtyDisplay}
            </span>
          ) : (
            <div className="flex items-center border border-gray-200 rounded overflow-hidden">
              <button
                onClick={handleDecrement}
                className="w-6 h-6 flex items-center justify-center bg-gray-100 hover:bg-gray-200"
                title="Remove one"
              >
                <Minus className="w-2.5 h-2.5" />
              </button>
              <span
                className={`text-center text-xs font-bold ${isScalable || isVariationLine ? "w-14 px-1" : "w-7"}`}
                title="Scan the item again to add more"
              >
                {qtyDisplay}
              </span>
            </div>
          )}
        </div>

        <div className="text-right w-16 flex-shrink-0">
          <p className="text-xs font-bold text-gray-900">
            {formatPrice(lineTotal)}
          </p>
        </div>
        <div className="flex flex-col gap-0.5">
          <button
            onClick={() => setShowDiscount(!showDiscount)}
            className="text-gray-400 hover:text-amber-500"
          >
            <Tag className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRemove}
            className="text-gray-400 hover:text-red-500"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      {showDiscount && (
        <div className="mt-2 flex items-center gap-2">
          <span className="text-xs text-gray-500">Item discount %:</span>
          <input
            type="number"
            min={0}
            max={100}
            value={item.discount || ""}
            onChange={(e) => onDiscountChange(parseFloat(e.target.value) || 0)}
            className="w-16 border border-gray-300 px-2 py-1 text-xs rounded focus:outline-none focus:border-green-400"
            placeholder="0"
          />
        </div>
      )}
    </div>
  );
}

// ── POSProductGrid ─────────────────────────────────────────────────────────────
// ✅ FIX 3: Touch-friendly visual product grid for busy POS environments.
// Cashiers can tap a product image to instantly add it to the cart instead
// of typing. A green badge shows the current quantity in cart; "Out" badge
// shows when stock is zero. Category pills at the top filter the grid.

interface POSProductGridProps {
  products: Product[];
  categories: { id: string; name: string }[];
  selectedCategory: string;
  onCategoryChange: (id: string) => void;
  loading: boolean;
  onAddToCart: (
    product: Product,
    presetQty?: number,
    variation?: ProductVariation,
  ) => void;
  cart: CartItem[];
  // Live checkout scale — when connected, tapping a weigh-eligible product
  // (loose, sold by kg/g, no pre-packaged variations) opens the weigh
  // modal instead of adding a default quantity.
  isScaleConnected: boolean;
  isWeighEligible: (product: Product) => boolean;
  onWeighProduct: (product: Product) => void;
}

function POSProductGrid({
  products,
  categories,
  selectedCategory,
  onCategoryChange,
  loading,
  onAddToCart,
  cart,
  isScaleConnected,
  isWeighEligible,
  onWeighProduct,
}: POSProductGridProps) {
  // Preset-only products (scaleStep = 0) can't be added with a default
  // quantity — tapping the tile opens this inline picker so the cashier
  // must explicitly choose one of the preset weights.
  const [pickerProduct, setPickerProduct] = useState<Product | null>(null);

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Category filter pills */}
      <div className="flex gap-2 px-3 py-2 border-b border-gray-200 bg-gray-50 overflow-x-auto flex-shrink-0 scrollbar-none">
        <button
          onClick={() => onCategoryChange("")}
          className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
            selectedCategory === ""
              ? "bg-green-600 text-white"
              : "bg-white border border-gray-200 text-gray-600 hover:border-green-400"
          }`}
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onCategoryChange(cat.id)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
              selectedCategory === cat.id
                ? "bg-green-600 text-white"
                : "bg-white border border-gray-200 text-gray-600 hover:border-green-400"
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto p-3">
        {loading ? (
          <div className="grid grid-cols-3 gap-2">
            {Array.from({ length: 12 }).map((_, i) => (
              <div
                key={i}
                className="aspect-square rounded-xl bg-gray-100 animate-pulse"
              />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Package className="w-12 h-12 mb-3 text-gray-200" />
            <p className="text-sm">No products found</p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {products.map((product) => {
              const inCart = cart.filter((i) => i.product.id === product.id);
              const inCartQty = inCart.reduce((s, i) => s + i.quantity, 0);
              const outOfStock = product.stockQuantity <= 0;
              const activeVariations = (product.variations || []).filter(
                (v) => v.isActive,
              );
              const hasVariations = activeVariations.length > 0;
              const presetOnly =
                !hasVariations &&
                !!product.isScalable &&
                (product.scaleStep ?? 0.1) === 0;
              // Legacy quick-select weights (a plain comma-separated list on
              // the product itself, not a structured variation) — set from
              // the "Preset Weights" field on the product's Scale/Weight
              // tab. These deserve the same picker treatment as
              // variations/presetOnly: without this, a product with
              // presets configured just went straight into being weighed
              // or added at a default quantity, and the presets only ever
              // surfaced as small buttons tacked onto the cart line
              // afterward — easy to miss entirely, which is exactly what
              // was reported ("I set preset values but can't see the
              // option to select").
              const hasLegacyPresets =
                !hasVariations &&
                !presetOnly &&
                !!product.isScalable &&
                (product.scalePresets?.length ?? 0) > 0;
              return (
                <button
                  key={product.id}
                  onClick={() => {
                    if (outOfStock) return;
                    if (hasVariations || presetOnly || hasLegacyPresets) {
                      setPickerProduct(product);
                    } else if (isScaleConnected && isWeighEligible(product)) {
                      onWeighProduct(product);
                    } else {
                      onAddToCart(product);
                    }
                  }}
                  disabled={outOfStock}
                  className={`relative flex flex-col rounded-xl border-2 overflow-hidden transition-all active:scale-95 text-left ${
                    outOfStock
                      ? "border-gray-100 opacity-50 cursor-not-allowed bg-gray-50"
                      : inCart.length > 0
                        ? "border-green-500 bg-green-50 shadow-md"
                        : "border-gray-200 bg-white hover:border-green-400 hover:shadow-sm"
                  }`}
                >
                  {/* Product image */}
                  <div className="aspect-square w-full bg-gray-100 overflow-hidden">
                    <img
                      src={getProductImage(product.images)}
                      alt={product.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>

                  {/* Cart quantity badge */}
                  {inCart.length > 0 && (
                    <span className="absolute top-1.5 right-1.5 bg-green-600 text-white text-[10px] font-bold min-w-5 h-5 px-1 rounded-full flex items-center justify-center shadow leading-none">
                      {hasVariations
                        ? `×${inCartQty}`
                        : product.isScalable
                          ? `${formatScaleQty(inCartQty, product.scaleStep)}${product.scaleUnit ? product.scaleUnit[0] : ""}`
                          : inCartQty}
                    </span>
                  )}

                  {/* Out of stock badge */}
                  {outOfStock && (
                    <span className="absolute top-1.5 left-1.5 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                      Out
                    </span>
                  )}

                  {/* Variation / scalable badge */}
                  {!outOfStock && hasVariations && (
                    <span className="absolute top-1.5 left-1.5 bg-emerald-700 text-white text-[8px] font-bold px-1 py-0.5 rounded flex items-center gap-0.5">
                      {activeVariations.length} option
                      {activeVariations.length === 1 ? "" : "s"}
                    </span>
                  )}
                  {!outOfStock && !hasVariations && product.isScalable && (
                    <span className="absolute top-1.5 left-1.5 bg-green-700 text-white text-[8px] font-bold px-1 py-0.5 rounded flex items-center gap-0.5">
                      ⚖ {product.scaleUnit || "unit"}
                      {isScaleConnected && isWeighEligible(product) && (
                        <span
                          className="w-1.5 h-1.5 rounded-full bg-lime-300 animate-pulse ml-0.5"
                          title="Live scale ready"
                        />
                      )}
                    </span>
                  )}

                  {/* Product info */}
                  <div className="p-1.5">
                    <p className="text-[11px] font-semibold text-gray-900 line-clamp-2 leading-tight">
                      {product.name}
                    </p>
                    <p className="text-[11px] font-bold text-green-700 mt-0.5">
                      {hasVariations
                        ? `From ${formatPrice(
                            Math.min(...activeVariations.map((v) => v.price)),
                          )}`
                        : product.isScalable && product.pricePerUnit
                          ? `${formatPrice(product.pricePerUnit)}/${product.scaleUnit || "unit"}`
                          : formatPrice(product.price)}
                    </p>
                    <p className="text-[9px] text-gray-400">
                      {hasVariations
                        ? "Tap to choose an option"
                        : product.isScalable
                          ? `${product.stockQuantity} ${product.scaleUnit || "unit"} left`
                          : `Qty: ${product.stockQuantity}`}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Option picker — shown when a product has structured variations
          (labeled presets like "500g Pack") or is a legacy preset-only
          (scaleStep = 0) scalable product. No default quantity is added;
          the cashier must explicitly choose an option. */}
      {pickerProduct && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4"
          onClick={() => setPickerProduct(null)}
        >
          <div
            className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-sm font-bold text-gray-900 line-clamp-2">
              {pickerProduct.name}
            </p>
            <p className="text-xs text-gray-500 mt-0.5 mb-3">
              Select an option to add it to the sale.
            </p>
            {(pickerProduct.variations || []).filter((v) => v.isActive).length >
            0 ? (
              <div className="flex flex-col gap-2">
                {(pickerProduct.variations || [])
                  .filter((v) => v.isActive)
                  .map((v) => {
                    const dedicated =
                      v.stockQuantity !== null && v.stockQuantity !== undefined;
                    const available = dedicated
                      ? (v.stockQuantity as number)
                      : pickerProduct.trackInventory
                        ? Math.floor(
                            (pickerProduct.stockQuantity ?? Infinity) /
                              v.quantity,
                          )
                        : Infinity;
                    const soldOut = available <= 0;
                    return (
                      <button
                        key={v.id}
                        disabled={soldOut}
                        onClick={() => {
                          onAddToCart(pickerProduct, undefined, v);
                          setPickerProduct(null);
                        }}
                        className={`flex items-center justify-between px-3 py-2.5 rounded-lg border text-left transition-colors ${
                          soldOut
                            ? "border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed"
                            : "border-gray-200 hover:border-green-500 hover:bg-green-50"
                        }`}
                      >
                        <span>
                          <span className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                            {v.label}
                            {v.isDefault && (
                              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1 rounded">
                                DEFAULT
                              </span>
                            )}
                          </span>
                          <span className="block text-[11px] text-gray-400 mt-0.5">
                            {soldOut
                              ? "Out of stock"
                              : Number.isFinite(available)
                                ? `${available} available`
                                : "In stock"}
                          </span>
                        </span>
                        <span className="text-sm font-bold text-green-700">
                          {formatPrice(v.price)}
                        </span>
                      </button>
                    );
                  })}
              </div>
            ) : (pickerProduct.scalePresets || []).length === 0 ? (
              <p className="text-xs text-red-500">
                No preset weights are configured for this product. Contact an
                admin to add some in Product Settings.
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {(pickerProduct.scalePresets || []).map((p) => (
                  <button
                    key={p}
                    onClick={() => {
                      onAddToCart(pickerProduct, p);
                      setPickerProduct(null);
                    }}
                    className="px-3 py-2 rounded-lg border border-gray-200 text-sm font-semibold text-gray-700 hover:border-green-500 hover:bg-green-50 transition-colors"
                  >
                    {p} {pickerProduct.scaleUnit || "unit"}
                  </button>
                ))}
              </div>
            )}
            {/* Presets here are a convenience shortcut, not a hard lock —
                unlike true preset-only (scaleStep = 0) products, this one
                still has a real step, so offer a way to weigh a custom
                amount instead of one of the quick presets. */}
            {(pickerProduct.scaleStep ?? 0.1) !== 0 &&
              (pickerProduct.variations || []).filter((v) => v.isActive)
                .length === 0 &&
              isScaleConnected &&
              isWeighEligible(pickerProduct) && (
                <button
                  onClick={() => {
                    setPickerProduct(null);
                    onWeighProduct(pickerProduct);
                  }}
                  className="mt-3 w-full py-2 text-sm font-medium text-green-700 border border-dashed border-green-300 rounded-lg hover:bg-green-50 transition-colors"
                >
                  Weigh a custom amount instead
                </button>
              )}
            <button
              onClick={() => setPickerProduct(null)}
              className="mt-4 w-full py-2 text-sm font-medium text-gray-500 hover:text-gray-700"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function POSPage() {
  return (
    <ScaleProvider>
      <POSPageInner />
    </ScaleProvider>
  );
}

// Small "5m ago" formatter for the catalog-sync status line — deliberately
// coarse (no seconds granularity) since it's a trust indicator, not a clock.
// ─── Resizable split + per-panel text size ───────────────────────────────────
// Cart width is stored as a % of the split container so it survives window
// resizes; text size is a CSS `zoom` factor per panel. Both persist per
// browser in localStorage.
const SPLIT_STORAGE_KEY = "pos.layout.v1";
const DEFAULT_CART_PCT = 42.8571;
const MIN_CART_PX = 320;
const MIN_LEFT_PX = 360;
const ZOOM_STEPS = [0.85, 1, 1.15, 1.3, 1.5, 1.75];

function nearestZoomIndex(z: unknown): number {
  const n = typeof z === "number" ? z : 1;
  let best = 1;
  ZOOM_STEPS.forEach((step, i) => {
    if (Math.abs(step - n) < Math.abs(ZOOM_STEPS[best] - n)) best = i;
  });
  return best;
}

function useResizableSplit() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [cartPct, setCartPct] = useState(DEFAULT_CART_PCT);
  const [leftZoomIdx, setLeftZoomIdx] = useState(1);
  const [rightZoomIdx, setRightZoomIdx] = useState(1);
  const [dragging, setDragging] = useState(false);
  const loaded = useRef(false);

  // Load saved layout after mount (avoids SSR/hydration mismatch)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(SPLIT_STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        if (
          typeof saved.cartPct === "number" &&
          saved.cartPct > 10 &&
          saved.cartPct < 90
        ) {
          setCartPct(saved.cartPct);
        }
        setLeftZoomIdx(nearestZoomIndex(saved.leftZoom));
        setRightZoomIdx(nearestZoomIndex(saved.rightZoom));
      }
    } catch {
      /* ignore corrupt/blocked storage */
    }
    loaded.current = true;
  }, []);

  // Persist (not while dragging — saved once on release)
  useEffect(() => {
    if (!loaded.current || dragging) return;
    try {
      localStorage.setItem(
        SPLIT_STORAGE_KEY,
        JSON.stringify({
          cartPct,
          leftZoom: ZOOM_STEPS[leftZoomIdx],
          rightZoom: ZOOM_STEPS[rightZoomIdx],
        }),
      );
    } catch {
      /* ignore */
    }
  }, [cartPct, leftZoomIdx, rightZoomIdx, dragging]);

  const setFromClientX = useCallback((clientX: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const maxCart = Math.max(MIN_CART_PX, rect.width - MIN_LEFT_PX);
    const cartPx = Math.min(maxCart, Math.max(MIN_CART_PX, rect.right - clientX));
    setCartPct((cartPx / rect.width) * 100);
  }, []);

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    setDragging(true);
    document.body.style.userSelect = "none";
    document.body.style.cursor = "col-resize";
  };
  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (dragging) setFromClientX(e.clientX);
  };
  const endDrag = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    if (e.currentTarget.hasPointerCapture(e.pointerId)) {
      e.currentTarget.releasePointerCapture(e.pointerId);
    }
    setDragging(false);
    document.body.style.userSelect = "";
    document.body.style.cursor = "";
  };
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowLeft") setCartPct((p) => Math.min(80, p + 2));
    else if (e.key === "ArrowRight") setCartPct((p) => Math.max(15, p - 2));
    else if (e.key === "Home") setCartPct(DEFAULT_CART_PCT);
    else return;
    e.preventDefault();
  };
  const reset = () => setCartPct(DEFAULT_CART_PCT);

  // Safety: never leave the body locked if unmounted mid-drag
  useEffect(
    () => () => {
      document.body.style.userSelect = "";
      document.body.style.cursor = "";
    },
    [],
  );

  return {
    containerRef,
    cartPct,
    dragging,
    dividerProps: {
      onPointerDown,
      onPointerMove,
      onPointerUp: endDrag,
      onPointerCancel: endDrag,
      onDoubleClick: reset,
      onKeyDown,
    },
    leftZoom: ZOOM_STEPS[leftZoomIdx],
    rightZoom: ZOOM_STEPS[rightZoomIdx],
    leftZoomIdx,
    rightZoomIdx,
    setLeftZoomIdx,
    setRightZoomIdx,
  };
}

function TextSizeControl({
  index,
  onChange,
  label,
}: {
  index: number;
  onChange: (i: number) => void;
  label: string;
}) {
  const max = ZOOM_STEPS.length - 1;
  return (
    <div
      className="flex items-center rounded border border-gray-200 bg-white overflow-hidden flex-shrink-0"
      role="group"
      aria-label={`${label} text size`}
    >
      <button
        type="button"
        onClick={() => onChange(Math.max(0, index - 1))}
        disabled={index === 0}
        title={`Smaller text (${label})`}
        className="px-2 py-1 text-[11px] font-bold text-gray-600 hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
      >
        A−
      </button>
      <button
        type="button"
        onClick={() => onChange(1)}
        title="Reset text size"
        className="px-1.5 py-1 text-[10px] font-semibold text-gray-500 hover:bg-gray-100 border-x border-gray-200 tabular-nums min-w-[38px]"
      >
        {Math.round(ZOOM_STEPS[index] * 100)}%
      </button>
      <button
        type="button"
        onClick={() => onChange(Math.min(max, index + 1))}
        disabled={index === max}
        title={`Larger text (${label})`}
        className="px-2 py-1 text-[13px] font-bold text-gray-700 hover:bg-gray-100 disabled:opacity-30 disabled:hover:bg-transparent"
      >
        A+
      </button>
    </div>
  );
}

function formatRelativeSync(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  return `${hours}h ago`;
}

function POSPageInner() {
  const { user } = useAuthStore();
  const scale = useScale();
  const toast = useToast();
  const split = useResizableSplit();

  // Offline product cache — see lib/posOfflineCache.ts. Keeps the full
  // sellable catalog in IndexedDB so every scan/search resolves instantly
  // off the local copy instead of waiting on the shop's connection.
  const catalogSync = useCatalogSync();

  // Session state
  const [session, setSession] = useState<POSSession | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [showCloseSession, setShowCloseSession] = useState(false);

  // Cart
  const [cart, setCart] = useState<CartItem[]>([]);
  // "Continue where you left off" — restores an in-progress cart (items
  // added but not yet held or checked out) after a logout/token-expiry/
  // closed-tab. Waits for the session to be ready before restoring so a
  // rebuilt cart isn't immediately confused with a brand-new session.
  // Cleared inside clearCart() below — the same choke point already hit
  // on both "sale completed" and "transaction held" success paths.
  const { restored: cartRestored, clearDraft: clearCartDraft } = useDraftSync({
    key: "pos-cart",
    state: cart,
    enabled: !sessionLoading && !!session,
    restoreWhen: !sessionLoading,
    shouldRestore: (payload) => Array.isArray(payload) && payload.length > 0,
    onRestore: (payload) => setCart(payload),
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    if (cartRestored) {
      toast("Restored your in-progress cart from before", "success");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cartRestored]);
  // Mirrors POSProductGrid's pickerProduct — the search bar and barcode
  // scanner are a separate render tree from the Quick-Add Grid, so they need
  // their own picker state to prompt for an option/preset instead of
  // silently falling through to the continuous-scale "₦/kg" default.
  const [searchPickerProduct, setSearchPickerProduct] =
    useState<Product | null>(null);
  // Product currently being weighed on the connected checkout scale (loose
  // items sold by weight — see the "Live weighing" section below).
  const [weighProduct, setWeighProduct] = useState<Product | null>(null);

  // Customer — "WALK_IN" is the generic walking customer option
  const [customerType, setCustomerType] = useState<"WALK_IN" | "NAMED">(
    "WALK_IN",
  );
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");

  // Discount
  const [couponCode, setCouponCode] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState<Discount | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);
  const [manualDiscount, setManualDiscount] = useState(0);
  const [showDiscountPanel, setShowDiscountPanel] = useState(false);

  // Payment
  const [showPayment, setShowPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("CASH");
  const [amountTendered, setAmountTendered] = useState("");
  const [splitPayments, setSplitPayments] = useState<SplitPayment[]>([
    { method: "CASH", amount: 0 },
    { method: "CARD", amount: 0 },
  ]);
  const [processing, setProcessing] = useState(false);
  const [paymentRef, setPaymentRef] = useState("");

  // Receipt
  const [completedOrder, setCompletedOrder] = useState<CompletedOrder | null>(
    null,
  );
  const [showReceipt, setShowReceipt] = useState(false);

  // Suspend / Resume
  const [suspendedOrders, setSuspendedOrders] = useState<SuspendedOrder[]>([]);
  const [showSuspendPanel, setShowSuspendPanel] = useState(false);
  const [suspendLabel, setSuspendLabel] = useState("");
  const [showSuspendDialog, setShowSuspendDialog] = useState(false);
  const [suspending, setSuspending] = useState(false);
  const [resuming, setResuming] = useState<string | null>(null); // orderId being resumed
  const [deletingSuspended, setDeletingSuspended] = useState<string | null>(
    null,
  ); // orderId being deleted
  // The DB id of the currently-active suspended order (set when we resume one)
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null);

  // ✅ FIX 3: Visual product grid state
  const [productGridMode, setProductGridMode] = useState<"search" | "grid">(
    "search",
  );
  const [gridProducts, setGridProducts] = useState<Product[]>([]);
  const [gridLoading, setGridLoading] = useState(false);
  const [gridCategory, setGridCategory] = useState("");
  const [gridCategories, setGridCategories] = useState<
    { id: string; name: string }[]
  >([]);

  const searchRef = useRef<HTMLInputElement>(null);
  const barcodeRef = useRef<HTMLInputElement>(null);
  // Product id of a scan that opened a picker; lets that picker's tap increment.
  const scanPickerProductRef = useRef<string | null>(null);

  // ── Auto-scroll the cart to the newly-added item ────────────────────────
  // With a long cart, a cashier scanning item after item shouldn't have to
  // manually scroll down each time to confirm the last scan landed —
  // scroll to the bottom whenever the cart grows (an actual add), but NOT
  // on every re-render (adjusting an existing line's qty/discount, or
  // removing an item, shouldn't yank the view).
  const cartListRef = useRef<HTMLDivElement>(null);
  const prevCartLengthRef = useRef(0);
  useEffect(() => {
    if (cart.length > prevCartLengthRef.current && cartListRef.current) {
      cartListRef.current.scrollTop = cartListRef.current.scrollHeight;
    }
    prevCartLengthRef.current = cart.length;
  }, [cart.length]);

  // ── Camera barcode scanner state ──────────────────────────────────────────
  const [showCameraScanner, setShowCameraScanner] = useState(false);
  // Drives the "Scanner ready" indicator next to the barcode box — purely
  // visual, so the cashier can see at a glance whether pulling the trigger
  // will actually land in this field right now.
  const [scannerFocused, setScannerFocused] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const scannerControlsRef = useRef<{ stop: () => void } | null>(null);

  // Keep the barcode-scan box focused whenever nothing else legitimately
  // needs the cursor. A USB scanner gun (the handheld kind, as opposed to
  // the camera scanner) behaves exactly like very fast keyboard typing
  // into whatever's currently focused, followed by Enter — this is what
  // lets the cashier just pull the trigger with zero clicking, as long as
  // this box already has focus when they do. Deliberately scoped to "cart
  // is empty" rather than always-on, so it doesn't fight a cashier who's
  // actively typing into the product search box or a modal.
  useEffect(() => {
    const modalOpen =
      !!searchPickerProduct ||
      !!weighProduct ||
      showPayment ||
      showReceipt ||
      showSuspendPanel ||
      showSuspendDialog ||
      showDiscountPanel ||
      showCloseSession ||
      showCameraScanner ||
      showSearch;

    if (!session || modalOpen) return;
    if (cart.length === 0) {
      barcodeRef.current?.focus();
    }
  }, [
    cart.length,
    session,
    searchPickerProduct,
    weighProduct,
    showPayment,
    showReceipt,
    showSuspendPanel,
    showSuspendDialog,
    showDiscountPanel,
    showCloseSession,
    showCameraScanner,
    showSearch,
  ]);

  // ✅ FIX 3: Load products + categories when grid mode is activated
  useEffect(() => {
    if (productGridMode !== "grid") return;
    const fetchGrid = async () => {
      setGridLoading(true);
      try {
        const params: any = { status: "ACTIVE", limit: 48 };
        if (gridCategory) params.categoryId = gridCategory;
        const [prodRes, catRes] = await Promise.all([
          apiGet<any>(`/products`, params),
          apiGet<any>(`/categories`),
        ]);
        setGridProducts(prodRes.data.products || []);
        setGridCategories(catRes.data.categories || []);
      } catch {
      } finally {
        setGridLoading(false);
      }
    };
    fetchGrid();
  }, [productGridMode, gridCategory]);

  // Load existing open session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await apiGet<any>("/pos/sessions?limit=1");
        const sessions: POSSession[] = res.data.sessions || [];
        const open = sessions.find((s) => s.status === "OPEN");
        setSession(open || null);
      } catch {
        setSession(null);
      } finally {
        setSessionLoading(false);
      }
    };
    checkSession();
  }, []);

  // Fetch suspended orders whenever the session is active
  const fetchSuspendedOrders = async () => {
    try {
      const res = await apiGet<any>("/pos/orders/suspended");
      setSuspendedOrders(res.data.orders || []);
    } catch {
      // silently ignore — suspended list is best-effort
    }
  };
  useEffect(() => {
    if (session) fetchSuspendedOrders();
  }, [session]);

  // ── Calculations ──
  const subtotal = cart.reduce(
    (s, i) => s + i.unitPrice * i.quantity * (1 - i.discount / 100),
    0,
  );
  const couponDiscount = (() => {
    if (!appliedDiscount) return 0;
    if (appliedDiscount.type === "PERCENTAGE") {
      const pct = (subtotal * appliedDiscount.value) / 100;
      return appliedDiscount.maxDiscount
        ? Math.min(pct, appliedDiscount.maxDiscount)
        : pct;
    }
    if (appliedDiscount.type === "FIXED_AMOUNT")
      return Math.min(appliedDiscount.value, subtotal);
    return 0;
  })();
  const totalDiscount = couponDiscount + manualDiscount;
  const total = Math.max(0, subtotal - totalDiscount);
  const change =
    paymentMethod === "CASH" && amountTendered
      ? Math.max(0, parseFloat(amountTendered || "0") - total)
      : 0;
  const splitTotal = splitPayments.reduce((s, p) => s + p.amount, 0);
  const splitRemaining = total - splitTotal;

  // Converts a cached catalog record (IndexedDB shape, nulls allowed) into
  // the `Product` shape the rest of this page already works with (string |
  // undefined, no cache-only fields) — keeps the offline path a drop-in
  // replacement for what the old network calls returned.
  const fromCachedProduct = (p: any): Product => ({
    ...p,
    barcode: p.barcode ?? undefined,
    scaleUnit: p.scaleUnit ?? undefined,
    scaleStep: p.scaleStep ?? undefined,
    scaleWareCode: p.scaleWareCode ?? undefined,
    variations: (p.variations || []).map((v: any) => ({
      ...v,
      compareAtPrice: v.compareAtPrice ?? undefined,
      barcode: v.barcode ?? undefined,
      stockQuantity: v.stockQuantity ?? undefined,
    })),
  });

  const handleSearch = useCallback(async (q: string) => {
    if (!q.trim()) {
      setSearchResults([]);
      return;
    }
    // Instant, local — no network round trip, so this never lags no
    // matter how bad the connection is. The catalog cache is kept fresh
    // in the background by useCatalogSync, so this is the live catalog
    // as of the last sync (seconds to a few minutes old at worst).
    setSearchLoading(true);
    try {
      const results = await searchLocal(q, 10);
      setSearchResults(results.map(fromCachedProduct));
    } catch {
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => handleSearch(searchQuery), 120);
    return () => clearTimeout(t);
  }, [searchQuery, handleSearch]);

  // Clears the scan box and puts the cursor straight back in it — a USB
  // scanner gun types into whatever's focused, so keeping focus here after
  // every scan (success or failure) is what lets the cashier just keep
  // pulling the trigger without touching the screen at all.
  const resetBarcodeInput = () => {
    if (barcodeRef.current) {
      barcodeRef.current.value = "";
      barcodeRef.current.focus();
    }
  };

  const scaleBarcodeErrorMessage = (err: ScaleBarcodeError): string => {
    switch (err.reason) {
      case "no-code":
        return `No product has scale code "${err.wareCode}" set at all. Set its "Scale Ware Code" in the product editor to match what the scale prints.`;
      case "not-scalable":
        return `"${err.name}" has scale code "${err.wareCode}" set, but isn't marked as a scalable product — check "This product is sold by measurement/scale" on its Scale/Weight tab and save.`;
      case "not-active":
        return `"${err.name}" has scale code "${err.wareCode}" set, but its status is ${err.status}, not ACTIVE — only active products can be scanned at checkout.`;
    }
  };

  const handleBarcode = async (rawCode: string) => {
    // Scanner guns often append a newline/space or a stray character
    // (and a pasted code can carry one too). The search box tolerates that
    // because it does a substring match; this exact-match path did not, so
    // the same product scanned in the search box but failed here.
    const code = rawCode.replace(/[\r\n\t]/g, "").trim();
    if (!code) {
      resetBarcodeInput();
      return;
    }

    // ── 1. Exact match on a registered product/variation barcode FIRST.
    // Previously any 18-digit code was assumed to be a scale-printed label
    // and sent straight down the scale path — so a product whose real
    // barcode happens to be 18 digits failed with "No product has scale
    // code … set at all". Scale labels embed the weight, so they never
    // equal a registered barcode; checking this first can't misfire.
    const exact = await lookupByBarcode(code);
    if (exact) {
      addOrPickVariation(
        fromCachedProduct(exact.product),
        exact.variation as any,
        true,
      );
      resetBarcodeInput();
      return;
    }

    // ── 2. Scale-printed barcode: resolved entirely from the local cache —
    // the weight is decoded from the digits themselves and the product
    // match only needs scaleWareCode, both already on-device. Falls back
    // to the network only if the cache has no candidate at all (e.g. a
    // scale code assigned in the last few seconds, before the next sync).
    // If an 18-digit code isn't a known scale label it may still be a
    // regular product barcode that just isn't in the local cache yet, so
    // a scale miss falls through to the SKU/network lookups below and only
    // reports the scale-specific error if everything else misses too.
    let scaleErrorMsg: string | null = null;
    if (isScaleBarcode(code)) {
      const cached = await lookupByScaleBarcode(code);
      if ("product" in cached) {
        addWeighedToCart(fromCachedProduct(cached.product), cached.weightKg);
        resetBarcodeInput();
        return;
      }
      scaleErrorMsg = scaleBarcodeErrorMessage(cached.error);
      if (catalogSync.isOnline) {
        try {
          const res = await apiGet<any>(`/pos/scale-barcode/${code}`);
          const { product, weightKg } = res.data;
          addWeighedToCart(product, weightKg);
          resetBarcodeInput();
          return;
        } catch (err) {
          scaleErrorMsg = getApiError(err);
        }
      }
    }

    // ── 3. Label carries the SKU instead of a registered barcode (the
    // search box finds these because it matches SKU too).
    const bySku = await lookupBySku(code);
    if (bySku) {
      addOrPickVariation(fromCachedProduct(bySku), undefined, true);
      resetBarcodeInput();
      return;
    }

    // Cache miss: either a genuinely unknown barcode, or a brand-new
    // product added moments ago that hasn't synced down yet. Only worth a
    // network round trip if we're actually online — offline, there's
    // nothing more to check, so fail fast instead of hanging.
    if (!catalogSync.isOnline) {
      toast(
        scaleErrorMsg ??
          `No product for barcode/SKU: ${code} (offline — will retry once back online)`,
        "error",
      );
      resetBarcodeInput();
      return;
    }

    try {
      const res = await apiGet<any>(
        `/products?barcode=${encodeURIComponent(code)}&status=ACTIVE&limit=1`,
      );
      const products = res.data.products || [];
      if (products.length > 0) {
        const product = products[0];
        // The scan can match either the product's own barcode or a
        // specific variation's dedicated barcode (e.g. a pre-labeled
        // "500g Pack" sticker) — route straight to that preset.
        const matchedVariation =
          normalizeBarcode(product.barcode) === code
            ? undefined
            : (product.variations || []).find(
                (v: ProductVariation) => normalizeBarcode(v.barcode) === code,
              );
        addOrPickVariation(product, matchedVariation, true);
      } else
        toast(
          scaleErrorMsg ??
            `No product matches "${code}" by barcode or SKU. Add this barcode to the product, or search it by name.`,
          "error",
        );
    } catch {
      toast("Barcode lookup failed", "error");
    } finally {
      resetBarcodeInput();
    }
  };

  // ── Camera scanner: start ZXing multi-format reader on the video element ──
  const stopCameraScanner = () => {
    if (scannerControlsRef.current) {
      try {
        scannerControlsRef.current.stop();
      } catch {}
      scannerControlsRef.current = null;
    }
    // Stop all camera tracks
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((t) => t.stop());
      videoRef.current.srcObject = null;
    }
    setShowCameraScanner(false);
  };

  const startCameraScanner = async () => {
    setShowCameraScanner(true);
    // Dynamically import ZXing so it doesn't bloat initial bundle
    try {
      const { BrowserMultiFormatReader } = await import("@zxing/browser");
      const reader = new BrowserMultiFormatReader();

      // Wait a tick for the video element to mount
      await new Promise((r) => setTimeout(r, 200));
      if (!videoRef.current) return;

      const controls = await reader.decodeFromConstraints(
        { video: { facingMode: "environment" } },
        videoRef.current,
        (result, error) => {
          if (result) {
            const code = result.getText();
            stopCameraScanner();
            handleBarcode(code);
          }
          // Suppress frame-by-frame "not found" errors — they are normal
          if (error && !error.message?.includes("No MultiFormat")) {
            // silent
          }
        },
      );
      scannerControlsRef.current = controls;
    } catch (err: any) {
      toast(
        err?.message?.includes("Permission")
          ? "Camera permission denied. Please allow camera access."
          : "Could not start camera scanner.",
        "error",
      );
      setShowCameraScanner(false);
    }
  };

  // `fromScan` = true only when the item came from the barcode scanner
  // (USB gun or camera). Only a scan may INCREASE an item already in the
  // cart; grid taps, search results and preset pickers can add a NEW line
  // but never bump an existing one.
  const addToCart = (
    product: Product,
    presetQty?: number,
    variation?: ProductVariation,
    fromScan = false,
  ) => {
    const scanAllowed = fromScan || scanPickerProductRef.current === product.id;
    scanPickerProductRef.current = null;
    if (!scanAllowed) {
      const alreadyInCart = cart.some(
        (i) =>
          i.product.id === product.id &&
          (variation
            ? i.variationId === variation.id
            : !i.variationId),
      );
      if (alreadyInCart) {
        toast(
          `${product.name} is already in the cart — scan it to add more`,
          "error",
        );
        return;
      }
    }
    // ── Structured preset/variation (e.g. "500g Pack") ────────────────────
    if (variation) {
      const dedicated =
        variation.stockQuantity !== null &&
        variation.stockQuantity !== undefined;
      const maxPacks = dedicated
        ? (variation.stockQuantity as number)
        : product.trackInventory
          ? Math.floor((product.stockQuantity ?? Infinity) / variation.quantity)
          : Infinity;

      setCart((prev) => {
        const existing = prev.find(
          (i) => i.product.id === product.id && i.variationId === variation.id,
        );
        if (existing) {
          if (existing.quantity + 1 > maxPacks) return prev;
          return prev.map((i) =>
            i === existing ? { ...i, quantity: i.quantity + 1 } : i,
          );
        }
        if (maxPacks < 1) return prev;
        return [
          ...prev,
          {
            product,
            quantity: 1,
            unitPrice: variation.price,
            discount: 0,
            variationId: variation.id,
            variationLabel: variation.label,
          },
        ];
      });
      setShowSearch(false);
      setSearchQuery("");
      setSearchResults([]);
      return;
    }

    const isScalable = !!product.isScalable;
    const step = product.scaleStep ?? 0.1;
    // Preset-only: scaleStep = 0 — there's no default increment quantity,
    // the cashier must have tapped an explicit preset weight (the grid
    // routes these through the preset picker before ever calling this
    // with presetQty set).
    const presetOnly = isScalable && step === 0;
    if (presetOnly && presetQty === undefined) {
      toast(`Select a preset weight for ${product.name}`, "error");
      return;
    }

    const unitPrice =
      isScalable && product.pricePerUnit ? product.pricePerUnit : product.price;
    const startQty =
      presetQty ?? (isScalable ? product.minOrderQty || step : 1);

    setCart((prev) => {
      const existing = prev.find(
        (i) => i.product.id === product.id && !i.variationId,
      );
      if (existing) {
        if (isScalable) {
          const maxQty = product.maxOrderQty
            ? Math.min(
                product.maxOrderQty,
                product.trackInventory ? product.stockQuantity : Infinity,
              )
            : product.trackInventory
              ? product.stockQuantity
              : Infinity;
          const next = presetOnly
            ? parseFloat(
                (existing.quantity + (presetQty as number)).toFixed(10),
              )
            : parseFloat(
                (Math.round((existing.quantity + step) / step) * step).toFixed(
                  10,
                ),
              );
          if (next > maxQty) return prev;
          return prev.map((i) =>
            i === existing ? { ...i, quantity: next } : i,
          );
        } else {
          const maxQty = product.trackInventory
            ? (product.stockQuantity ?? Infinity)
            : Infinity;
          if (existing.quantity >= maxQty) return prev;
          return prev.map((i) =>
            i === existing ? { ...i, quantity: i.quantity + 1 } : i,
          );
        }
      }
      return [...prev, { product, quantity: startQty, unitPrice, discount: 0 }];
    });

    // Warn if at stock limit (fixed products)
    if (!isScalable) {
      const inCart = cart.find((i) => i.product.id === product.id);
      if (
        inCart &&
        product.trackInventory &&
        inCart.quantity >= (product.stockQuantity ?? Infinity)
      ) {
        toast(`Stock limit reached for ${product.name}`, "error");
      }
    }

    setShowSearch(false);
    setSearchQuery("");
    setSearchResults([]);
  };

  // ── Live weighing (checkout scale) ──────────────────────────────────────
  // Only loose products actually sold in a mass unit the physical scale can
  // read (kg/g) go through the "put it on the scale" flow. Pre-packaged
  // variations (e.g. "500g Pack") and volume/count-based scalable products
  // (L, cup, custom) keep their existing picker/step behaviour untouched.
  const isWeighEligible = (product: Product) => {
    const activeVariations = (product.variations || []).filter(
      (v) => v.isActive,
    );
    if (activeVariations.length > 0) return false;
    if (!product.isScalable) return false;
    if ((product.scaleStep ?? 0.1) === 0) return false; // preset-only
    return product.scaleUnit === "kg" || product.scaleUnit === "g";
  };

  // Reads the live, stable weight off the connected scale and adds/merges
  // it into the cart line for this product (summed with any existing
  // weighed quantity for the same product, matching how the rest of the
  // cart already treats one line per product).
  const addWeighedToCart = (product: Product, weightKg: number) => {
    const quantityInScaleUnit =
      product.scaleUnit === "g" ? weightKg * 1000 : weightKg;
    const step = product.scaleStep ?? 0.1;
    const rounded = parseFloat(
      (Math.round(quantityInScaleUnit / step) * step).toFixed(10),
    );
    const unit = product.scaleUnit || "unit";
    const minQty = product.minOrderQty || step;
    if (rounded < minQty) {
      toast(`Weight is below the minimum sale of ${minQty} ${unit}`, "error");
      return;
    }
    const unitPrice =
      product.isScalable && product.pricePerUnit
        ? product.pricePerUnit
        : product.price;
    const maxStock = product.trackInventory
      ? (product.stockQuantity ?? Infinity)
      : Infinity;
    const maxQty = product.maxOrderQty
      ? Math.min(product.maxOrderQty, maxStock)
      : maxStock;

    let added = false;
    setCart((prev) => {
      const existing = prev.find(
        (i) => i.product.id === product.id && !i.variationId,
      );
      if (existing) {
        const next = parseFloat((existing.quantity + rounded).toFixed(10));
        if (next > maxQty) {
          toast(
            `Only ${maxQty} ${unit} available for ${product.name}`,
            "error",
          );
          return prev;
        }
        added = true;
        return prev.map((i) => (i === existing ? { ...i, quantity: next } : i));
      }
      if (rounded > maxQty) {
        toast(`Only ${maxQty} ${unit} available for ${product.name}`, "error");
        return prev;
      }
      added = true;
      return [...prev, { product, quantity: rounded, unitPrice, discount: 0 }];
    });
    if (added) {
      toast(
        `Added ${rounded} ${unit} of ${product.name} from the scale`,
        "success",
      );
      setWeighProduct(null);
    }
  };

  // Used by both the search-results dropdown and barcode scan: a product
  // with structured variations (or a legacy preset-only scalable product)
  // can't be added with a single click — which option/weight it is has to
  // be chosen first. `matchedVariation` is already resolved when a scan hit
  // a specific preset's own barcode, so that case skips the picker.
  const addOrPickVariation = (
    product: Product,
    matchedVariation?: ProductVariation,
    fromScan = false,
  ) => {
    // A scan that has to open a picker/weigh modal first remembers which
    // product it was for, so the follow-up tap in the picker may increment.
    scanPickerProductRef.current = null;
    if (matchedVariation) {
      addToCart(product, undefined, matchedVariation, fromScan);
      return;
    }
    const activeVariations = (product.variations || []).filter(
      (v) => v.isActive,
    );
    const hasVariations = activeVariations.length > 0;
    const presetOnly =
      !hasVariations &&
      !!product.isScalable &&
      (product.scaleStep ?? 0.1) === 0;
    // See the matching comment in the product-grid onClick handler above —
    // legacy scalePresets get the same picker treatment here too, so a
    // barcode scan or search-result tap for a preset-configured product
    // offers the presets immediately instead of silently skipping them.
    const hasLegacyPresets =
      !hasVariations &&
      !presetOnly &&
      !!product.isScalable &&
      (product.scalePresets?.length ?? 0) > 0;
    if (hasVariations || presetOnly || hasLegacyPresets) {
      if (fromScan) scanPickerProductRef.current = product.id;
      setSearchPickerProduct(product);
      setShowSearch(false);
      return;
    }
    if (isWeighEligible(product) && scale.status === "connected") {
      setWeighProduct(product);
      setShowSearch(false);
      return;
    }
    addToCart(product, undefined, undefined, fromScan);
  };

  // Decrease-only: the cashier can never raise a quantity by hand — that's
  // enforced here as well as in the UI. Increases come only from addToCart
  // with fromScan.
  const updateQty = (productId: string, qty: number, variationId?: string) => {
    if (qty <= 0) {
      setCart((p) =>
        p.filter(
          (i) =>
            !(
              i.product.id === productId &&
              (i.variationId ?? undefined) === variationId
            ),
        ),
      );
      return;
    }
    setCart((p) =>
      p.map((i) =>
        i.product.id === productId &&
        (i.variationId ?? undefined) === variationId &&
        qty < i.quantity
          ? { ...i, quantity: qty }
          : i,
      ),
    );
  };

  const updateItemDiscount = (
    productId: string,
    pct: number,
    variationId?: string,
  ) => {
    setCart((p) =>
      p.map((i) =>
        i.product.id === productId &&
        (i.variationId ?? undefined) === variationId
          ? { ...i, discount: Math.min(100, Math.max(0, pct)) }
          : i,
      ),
    );
  };

  // Abandoning a cart that was resumed from a hold would otherwise leave
  // its OPEN draft in the database forever. Best-effort delete; skipped
  // when the cart was just completed (the server already removed the draft).
  const discardActiveDraft = (orderId: string | null) => {
    if (!orderId) return;
    apiDelete(`/pos/orders/${orderId}/suspended`).catch(() => {});
  };

  const clearCart = (opts?: { keepDraft?: boolean }) => {
    if (!opts?.keepDraft) discardActiveDraft(activeOrderId);
    setCart([]);
    clearCartDraft();
    setAppliedDiscount(null);
    setCouponCode("");
    setManualDiscount(0);
    setCustomerName("");
    setCustomerPhone("");
    setAmountTendered("");
    setPaymentRef("");
    setShowPayment(false);
    setShowDiscountPanel(false);
    setCustomerType("WALK_IN");
    setActiveOrderId(null);
  };

  // ── Suspend current transaction ──────────────────────────────────────────
  const handleSuspend = async () => {
    if (cart.length === 0) {
      toast("Cart is empty — nothing to suspend.", "error");
      return;
    }
    setSuspending(true);
    try {
      // Use the dedicated /hold endpoint which saves as SUSPENDED without
      // touching stock (stock is only deducted when the order is completed).
      const holdData = {
        items: cart.map((item) => ({
          productId: item.product.id,
          productName: item.product.name,
          productSku: item.product.sku,
          barcode: item.product.barcode,
          netWeight: item.product.netWeight,
          scaleUnit: item.product.isScalable
            ? (item.product.scaleUnit ?? null)
            : null,
          variationId: item.variationId,
          variationLabel: item.variationLabel,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          subtotal: item.unitPrice * item.quantity * (1 - item.discount / 100),
          discountApplied: item.discount,
        })),
        subtotal,
        discountAmount: totalDiscount,
        discountCode: appliedDiscount?.code,
        total,
        customerName:
          customerType === "WALK_IN"
            ? "Walk-In Customer"
            : customerName || undefined,
        customerPhone:
          customerType === "WALK_IN" ? undefined : customerPhone || undefined,
        label: suspendLabel.trim() || undefined,
      };

      await apiPost<any>("/pos/orders/hold", holdData);

      toast("Transaction held. Serve the next customer!", "success");
      setShowSuspendDialog(false);
      setSuspendLabel("");
      clearCart();
      fetchSuspendedOrders();
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setSuspending(false);
    }
  };

  // ── Resume a suspended transaction ───────────────────────────────────────
  const handleResume = async (order: SuspendedOrder) => {
    if (cart.length > 0) {
      toast(
        "Please suspend or clear the current cart before resuming another transaction.",
        "error",
      );
      return;
    }
    setResuming(order.id);
    try {
      await apiPut<any>(`/pos/orders/${order.id}/resume`, {});

      // Rebuild cart from the suspended order items
      const rebuiltCart: CartItem[] = order.items.map((item) => ({
        product: {
          id: item.productId,
          name: item.productName,
          sku: item.productSku,
          barcode: item.barcode ?? undefined,
          price: item.unitPrice,
          stockQuantity: 9999, // actual stock validated server-side on resume
          images: [],
          trackInventory: false,
          netWeight: item.netWeight ?? undefined,
          isScalable: !!item.scaleUnit,
          scaleUnit: item.scaleUnit ?? undefined,
          pricePerUnit: item.scaleUnit ? item.unitPrice : undefined,
        } as Product,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        discount: item.discountApplied,
        variationId: item.variationId ?? undefined,
        variationLabel: item.variationLabel ?? undefined,
      }));

      setCart(rebuiltCart);
      setActiveOrderId(order.id);
      if (order.customerName && order.customerName !== "Walk-In Customer") {
        setCustomerType("NAMED");
        setCustomerName(order.customerName);
      }

      setSuspendedOrders((prev) => prev.filter((o) => o.id !== order.id));
      setShowSuspendPanel(false);
      toast(`Resumed: ${order.posOrderNumber}`, "success");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setResuming(null);
    }
  };

  // ── Delete/cancel a held (suspended) transaction ─────────────────────────
  // Open to every POS role — a held order never had stock deducted or
  // payment taken, so there's nothing to approve or restore.
  const handleDeleteSuspended = async (order: SuspendedOrder) => {
    if (
      !window.confirm(
        `Delete held transaction "${order.posOrderNumber}"? This cannot be undone.`,
      )
    ) {
      return;
    }
    setDeletingSuspended(order.id);
    try {
      await apiDelete(`/pos/orders/${order.id}/suspended`);
      setSuspendedOrders((prev) => prev.filter((o) => o.id !== order.id));
      toast(`Held transaction "${order.posOrderNumber}" deleted`, "success");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setDeletingSuspended(null);
    }
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    try {
      const res = await apiPost<any>("/discounts/validate", {
        code: couponCode.trim().toUpperCase(),
        orderAmount: subtotal,
      });
      if (res.data.valid) {
        setAppliedDiscount(res.data.discount);
        toast("Coupon applied!", "success");
      } else toast(res.data.message || "Invalid coupon", "error");
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setCouponLoading(false);
    }
  };

  // Print exactly one merchant copy and one customer copy through the
  // shared receipt printer bridge. In the Electron desktop app,
  // lib/posReceipt.ts detects the posDesktop bridge and uses silentPrint()
  // instead of Chrome/window.print(). Keeping a single printing path here
  // prevents the POS page from accidentally creating an additional browser
  // print job alongside the Electron bridge.
  const printCurrentReceipt = () => {
    if (!completedOrder) return;

    const printOrder = {
      id: completedOrder.posOrderNumber,
      posOrderNumber: completedOrder.posOrderNumber,
      receiptNumber: completedOrder.receiptNumber,
      status: "COMPLETED" as const,
      paymentMethod: completedOrder.paymentMethod,
      subtotal: completedOrder.subtotal,
      discountAmount: completedOrder.discountAmount,
      total: completedOrder.total,
      amountTendered: completedOrder.amountTendered,
      changeGiven: completedOrder.changeGiven,
      customerName: completedOrder.customerName,
      customerPhone: completedOrder.customerPhone,
      createdAt: completedOrder.processedAt.toISOString(),
      items: completedOrder.items.map((item, index) => ({
        id: `${completedOrder.posOrderNumber}-${index}`,
        productName: item.product.name,
        productSku: item.product.sku,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        subtotal: item.unitPrice * item.quantity * (1 - item.discount / 100),
        discountApplied: item.discount,
        netWeight: item.product.netWeight,
        scaleUnit: item.product.isScalable
          ? (item.product.scaleUnit ?? undefined)
          : undefined,
        variationLabel: item.variationLabel ?? null,
      })),
      processedBy: { name: "POS", role: "CASHIER" },
    };

    printBothReceipts(printOrder);
  };

  const processPayment = async () => {
    if (cart.length === 0) {
      toast("Cart is empty", "error");
      return;
    }
    if (!session) {
      toast("No open session. Please open a session first.", "error");
      return;
    }

    if (paymentMethod === "CASH") {
      if (parseFloat(amountTendered || "0") < total) {
        toast(`Need ${formatPrice(total)}`, "error");
        return;
      }
    }
    if (paymentMethod === "SPLIT" && splitRemaining > 0.01) {
      toast(`Split is short by ${formatPrice(splitRemaining)}`, "error");
      return;
    }

    setProcessing(true);
    try {
      const orderData = {
        items: cart.map((item) => ({
          productId: item.product.id,
          productName: item.product.name,
          productSku: item.product.sku,
          barcode: item.product.barcode,
          netWeight: item.product.netWeight,
          scaleUnit: item.product.isScalable
            ? (item.product.scaleUnit ?? null)
            : null,
          variationId: item.variationId,
          variationLabel: item.variationLabel,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          subtotal: item.unitPrice * item.quantity * (1 - item.discount / 100),
          discountApplied: item.discount,
        })),
        subtotal,
        discountAmount: totalDiscount,
        discountCode: appliedDiscount?.code,
        total,
        paymentMethod,
        amountTendered:
          paymentMethod === "CASH" ? parseFloat(amountTendered) : undefined,
        changeGiven: paymentMethod === "CASH" ? change : undefined,
        splitPayments: paymentMethod === "SPLIT" ? splitPayments : undefined,
        paymentReference: paymentRef || undefined,
        // Walking customer uses generic label; named customer uses entered name
        customerName:
          customerType === "WALK_IN"
            ? "Walk-In Customer"
            : customerName || undefined,
        customerPhone:
          customerType === "WALK_IN" ? undefined : customerPhone || undefined,
        sessionId: session.id,
      };

      // If this cart was resumed from a hold, the server deletes that draft
      // as part of creating the sale. (This used to call the ADMIN-only
      // /void endpoint first and swallow the 403, which left an OPEN ghost
      // order behind for every non-admin cashier.)
      const res = await apiPost<any>("/pos/orders", {
        ...orderData,
        ...(activeOrderId ? { resumedFromOrderId: activeOrderId } : {}),
      });
      const order = res.data.order;

      setCompletedOrder({
        posOrderNumber: order.posOrderNumber,
        items: cart,
        subtotal,
        discountAmount: totalDiscount,
        total,
        paymentMethod,
        amountTendered:
          paymentMethod === "CASH" ? parseFloat(amountTendered) : undefined,
        changeGiven: paymentMethod === "CASH" ? change : undefined,
        splitPayments: paymentMethod === "SPLIT" ? splitPayments : undefined,
        customerName:
          customerType === "WALK_IN"
            ? "Walk-In Customer"
            : customerName || undefined,
        customerPhone: customerType === "NAMED" ? customerPhone : undefined,
        processedAt: new Date(),
        receiptNumber: order.receiptNumber || order.posOrderNumber,
      });

      // Update local session stats
      setSession((prev) =>
        prev
          ? {
              ...prev,
              totalOrders: prev.totalOrders + 1,
              totalSales: prev.totalSales + total,
              cashSales:
                prev.cashSales + (paymentMethod === "CASH" ? total : 0),
              cardSales:
                prev.cardSales + (paymentMethod === "CARD" ? total : 0),
              transferSales:
                prev.transferSales + (paymentMethod === "TRANSFER" ? total : 0),
            }
          : prev,
      );

      setShowReceipt(true);
      setShowPayment(false);
      clearCart({ keepDraft: true }); // server already deleted the resumed draft
    } catch (err) {
      toast(getApiError(err), "error");
    } finally {
      setProcessing(false);
    }
  };

  const quickAmounts = [500, 1000, 2000, 5000, 10000, 20000].filter(
    (a) => a >= total,
  );

  if (sessionLoading) {
    return (
      <div className="h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-green-400" />
      </div>
    );
  }

  if (!session) {
    return <SessionGate onOpen={(s) => setSession(s)} />;
  }

  return (
    <div className="h-screen flex flex-col bg-gray-100 overflow-hidden">
      {/* ── Top Bar ── */}
      <div className="bg-gray-900 text-white px-4 py-2 flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <ShoppingCart className="w-5 h-5 text-green-400" />
          <span className="font-bold text-sm">NigitTriple POS</span>
          {user && <span className="text-gray-400 text-xs">| {user.name}</span>}
          <span className="bg-green-800 text-green-200 text-[10px] px-2 py-0.5 rounded-full">
            Session Open
          </span>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="text-gray-300">
            <span className="text-green-400 font-bold">
              {session.totalOrders}
            </span>{" "}
            orders
            {" | "}
            <span className="text-green-400 font-bold">
              {formatPrice(session.totalSales)}
            </span>
          </div>
          <div className="bg-green-600 text-white px-2 py-1 rounded text-xs font-semibold flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {new Date().toLocaleTimeString("en-NG", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
          {/* Checkout scale connect/status button */}
          <ScalePanel />
          {/* Held transactions quick-access button */}
          <button
            onClick={() => {
              fetchSuspendedOrders();
              setShowSuspendPanel(true);
            }}
            className={`relative px-3 py-1 rounded text-xs font-semibold flex items-center gap-1 transition-colors ${suspendedOrders.length > 0 ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-gray-700 hover:bg-gray-600 text-gray-300"}`}
            title="View held transactions"
          >
            <PauseCircle className="w-3 h-3" /> Held
            {suspendedOrders.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {suspendedOrders.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setShowCloseSession(true)}
            className="bg-red-700 hover:bg-red-600 text-white px-3 py-1 rounded text-xs font-semibold flex items-center gap-1"
          >
            <LogOut className="w-3 h-3" /> Close Session
          </button>
        </div>
      </div>

      <div ref={split.containerRef} className="flex flex-1 overflow-hidden">
        {/* ── LEFT: Product Search + Visual Grid ── */}
        <div className="flex-1 min-w-0 flex flex-col overflow-hidden bg-white relative">
          <div
            className="flex-1 min-h-0 flex flex-col overflow-hidden relative"
            style={{ zoom: split.leftZoom }}
          >
          {/* ✅ FIX 3: Tab toggle — Search/Scan vs Quick-Add Grid */}
          <div className="flex border-b border-gray-200 bg-gray-50 flex-shrink-0">
            <button
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors ${
                productGridMode === "search"
                  ? "bg-white border-b-2 border-green-600 text-green-700"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setProductGridMode("search")}
            >
              <LayoutList className="w-3.5 h-3.5" /> Search / Scan
            </button>
            <button
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors ${
                productGridMode === "grid"
                  ? "bg-white border-b-2 border-green-600 text-green-700"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setProductGridMode("grid")}
            >
              <Grid3x3 className="w-3.5 h-3.5" /> Quick-Add Grid
            </button>
            <div className="flex items-center px-2 border-l border-gray-200">
              <TextSizeControl
                label="left panel"
                index={split.leftZoomIdx}
                onChange={split.setLeftZoomIdx}
              />
            </div>
          </div>

          {/* ── SEARCH MODE ── */}
          {productGridMode === "search" && (
            <>
              <div className="p-3 border-b border-gray-200 bg-gray-50">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      ref={searchRef}
                      type="text"
                      placeholder="Search product by name or SKU..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setShowSearch(true);
                      }}
                      onFocus={() => setShowSearch(true)}
                      className="w-full pl-9 pr-4 py-2.5 border border-gray-300 text-sm focus:outline-none focus:border-green-500 rounded bg-white"
                    />
                    {searchLoading && (
                      <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-gray-400" />
                    )}
                  </div>
                  <div className="relative">
                    <Barcode
                      className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 transition-colors ${
                        scannerFocused ? "text-amber-500" : "text-gray-400"
                      }`}
                    />
                    <input
                      ref={barcodeRef}
                      type="text"
                      placeholder="Scan barcode"
                      onFocus={() => setScannerFocused(true)}
                      onBlur={() => setScannerFocused(false)}
                      className={`pl-9 pr-4 py-2.5 border text-sm focus:outline-none rounded bg-white w-40 transition-shadow ${
                        scannerFocused
                          ? "border-amber-500 ring-2 ring-amber-200"
                          : "border-gray-300 focus:border-amber-500"
                      }`}
                      onKeyDown={(e) => {
                        if (e.key === "Enter")
                          handleBarcode(e.currentTarget.value);
                      }}
                    />
                  </div>
                  {/* Camera scan button */}
                  <button
                    onClick={startCameraScanner}
                    title="Scan with camera"
                    className="flex items-center gap-1.5 px-3 py-2.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded transition-colors"
                  >
                    <Camera className="w-4 h-4" />
                    <span className="hidden sm:inline">Camera</span>
                  </button>
                </div>

                {/* Scanner-gun readiness indicator. A USB scanner gun just
                    "types" into whatever text field is focused, so this is
                    the cashier's only visual cue that pulling the trigger
                    right now will land a scan in the box above. In normal
                    flow (not floated over anything) so it can't collide
                    with the search-results dropdown right below it. */}
                <div
                  className={`mt-1.5 flex items-center gap-1.5 text-[11px] font-medium transition-colors ${
                    scannerFocused ? "text-green-700" : "text-gray-400"
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                      scannerFocused
                        ? "bg-green-500 animate-pulse"
                        : "bg-gray-300"
                    }`}
                  />
                  {scannerFocused
                    ? "Scanner ready — pull the trigger on any barcode"
                    : "Click the barcode box, or a USB scanner gun will type into it automatically"}
                </div>

                {/* Offline catalog cache status — the whole point of this
                    is to make the cashier trust the scan even when the
                    shop's connection is bad, so surface it plainly rather
                    than hide it. */}
                <div className="mt-1 flex items-center gap-1.5 text-[11px] text-gray-400">
                  <span
                    className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                      catalogSync.isOnline ? "bg-blue-400" : "bg-amber-500"
                    }`}
                  />
                  {!catalogSync.isOnline
                    ? `Offline — using cached catalog (${catalogSync.productCount} products)`
                    : catalogSync.isSyncing
                      ? "Syncing catalog…"
                      : catalogSync.lastSyncedAt
                        ? `Catalog synced ${formatRelativeSync(catalogSync.lastSyncedAt)} · ${catalogSync.productCount} products`
                        : `${catalogSync.productCount} products cached`}
                </div>

                {/* Search results dropdown */}
                {showSearch && searchResults.length > 0 && (
                  <div className="absolute z-50 mt-1 bg-white border border-gray-200 rounded shadow-lg max-h-64 overflow-y-auto w-[calc(100%-2rem)]">
                    {searchResults.map((product) => (
                      <button
                        key={product.id}
                        onClick={() => addOrPickVariation(product)}
                        className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-green-50 text-left border-b border-gray-100 last:border-0"
                      >
                        <div className="w-8 h-8 bg-gray-100 rounded flex-shrink-0 overflow-hidden">
                          <img
                            src={getProductImage(product.images)}
                            alt=""
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {product.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {product.sku}
                            {product.netWeight && ` · ${product.netWeight}`}
                          </p>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="text-sm font-bold">
                            {(product.variations || []).filter(
                              (v) => v.isActive,
                            ).length > 0
                              ? `From ${formatPrice(
                                  Math.min(
                                    ...(product.variations || [])
                                      .filter((v) => v.isActive)
                                      .map((v) => v.price),
                                  ),
                                )}`
                              : product.isScalable && product.pricePerUnit
                                ? `${formatPrice(product.pricePerUnit)}/${product.scaleUnit || "unit"}`
                                : formatPrice(product.price)}
                          </p>
                          <p className="text-xs text-gray-400">
                            {(product.variations || []).filter(
                              (v) => v.isActive,
                            ).length > 0
                              ? "Tap to choose"
                              : `Qty: ${product.stockQuantity}`}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div
                className="flex-1 overflow-y-auto p-3"
                onClick={() => setShowSearch(false)}
              >
                {cart.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-gray-400">
                    <Package className="w-16 h-16 mb-4 text-gray-200" />
                    <p className="text-sm">
                      Search for products or scan a barcode
                    </p>
                    <p className="text-xs mt-1 text-gray-300">
                      Or switch to Quick-Add Grid for touch-friendly browsing
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-gray-400 text-center mt-4">
                    {cart.length} item(s) in cart →
                  </p>
                )}
              </div>
            </>
          )}

          {/* ── VISUAL GRID MODE ── */}
          {productGridMode === "grid" && (
            <POSProductGrid
              products={gridProducts}
              categories={gridCategories}
              selectedCategory={gridCategory}
              onCategoryChange={setGridCategory}
              loading={gridLoading}
              onAddToCart={addToCart}
              cart={cart}
              isScaleConnected={scale.status === "connected"}
              isWeighEligible={isWeighEligible}
              onWeighProduct={setWeighProduct}
            />
          )}

          {/* Live weighing modal — put a loose item on the connected scale
              and add exactly what it weighs, priced per the product's
              pricePerUnit. Falls back to manual entry if the scale isn't
              connected or the cashier prefers the old flow. */}
          {weighProduct && (
            <WeighModal
              product={weighProduct}
              onClose={() => setWeighProduct(null)}
              onAdd={(_, weightKg) => addWeighedToCart(weighProduct, weightKg)}
              onAddManually={() => {
                const p = weighProduct;
                setWeighProduct(null);
                if (p) addToCart(p);
              }}
            />
          )}

          {/* Option picker for products found via Search/Scan or barcode —
              mirrors POSProductGrid's picker so choosing a preset works the
              same way no matter how the product was found. */}
          {searchPickerProduct && (
            <div
              className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 p-4"
              onClick={() => setSearchPickerProduct(null)}
            >
              <div
                className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-4"
                onClick={(e) => e.stopPropagation()}
              >
                <p className="text-sm font-bold text-gray-900 line-clamp-2">
                  {searchPickerProduct.name}
                </p>
                <p className="text-xs text-gray-500 mt-0.5 mb-3">
                  Select an option to add it to the sale.
                </p>
                {(searchPickerProduct.variations || []).filter(
                  (v) => v.isActive,
                ).length > 0 ? (
                  <div className="flex flex-col gap-2">
                    {(searchPickerProduct.variations || [])
                      .filter((v) => v.isActive)
                      .map((v) => {
                        const dedicated =
                          v.stockQuantity !== null &&
                          v.stockQuantity !== undefined;
                        const available = dedicated
                          ? (v.stockQuantity as number)
                          : searchPickerProduct.trackInventory
                            ? Math.floor(
                                (searchPickerProduct.stockQuantity ??
                                  Infinity) / v.quantity,
                              )
                            : Infinity;
                        const soldOut = available <= 0;
                        return (
                          <button
                            key={v.id}
                            disabled={soldOut}
                            onClick={() => {
                              addToCart(searchPickerProduct, undefined, v);
                              setSearchPickerProduct(null);
                            }}
                            className={`flex items-center justify-between px-3 py-2.5 rounded-lg border text-left transition-colors ${
                              soldOut
                                ? "border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed"
                                : "border-gray-200 hover:border-green-500 hover:bg-green-50"
                            }`}
                          >
                            <span>
                              <span className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                                {v.label}
                                {v.isDefault && (
                                  <span className="text-[9px] font-bold text-emerald-700 bg-emerald-100 px-1 rounded">
                                    DEFAULT
                                  </span>
                                )}
                              </span>
                              <span className="block text-[11px] text-gray-400 mt-0.5">
                                {soldOut
                                  ? "Out of stock"
                                  : Number.isFinite(available)
                                    ? `${available} available`
                                    : "In stock"}
                              </span>
                            </span>
                            <span className="text-sm font-bold text-green-700">
                              {formatPrice(v.price)}
                            </span>
                          </button>
                        );
                      })}
                  </div>
                ) : (searchPickerProduct.scalePresets || []).length === 0 ? (
                  <p className="text-xs text-red-500">
                    No preset weights are configured for this product. Contact
                    an admin to add some in Product Settings.
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {(searchPickerProduct.scalePresets || []).map((p) => (
                      <button
                        key={p}
                        onClick={() => {
                          addToCart(searchPickerProduct, p);
                          setSearchPickerProduct(null);
                        }}
                        className="px-3 py-2 rounded-lg border border-gray-200 text-sm font-semibold text-gray-700 hover:border-green-500 hover:bg-green-50 transition-colors"
                      >
                        {p} {searchPickerProduct.scaleUnit || "unit"}
                      </button>
                    ))}
                  </div>
                )}
                {/* Same escape hatch as the grid picker — see the matching
                    comment there. */}
                {(searchPickerProduct.scaleStep ?? 0.1) !== 0 &&
                  (searchPickerProduct.variations || []).filter(
                    (v) => v.isActive,
                  ).length === 0 &&
                  scale.status === "connected" &&
                  isWeighEligible(searchPickerProduct) && (
                    <button
                      onClick={() => {
                        setSearchPickerProduct(null);
                        setWeighProduct(searchPickerProduct);
                      }}
                      className="mt-3 w-full py-2 text-sm font-medium text-green-700 border border-dashed border-green-300 rounded-lg hover:bg-green-50 transition-colors"
                    >
                      Weigh a custom amount instead
                    </button>
                  )}
                <button
                  onClick={() => setSearchPickerProduct(null)}
                  className="mt-4 w-full py-2 text-sm font-medium text-gray-500 hover:text-gray-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
          </div>
        </div>

        {/* ── Draggable divider ── */}
        <div
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize product and cart panels (double-click to reset)"
          tabIndex={0}
          {...split.dividerProps}
          style={{ touchAction: "none" }}
          className={`group relative w-1.5 flex-shrink-0 cursor-col-resize select-none outline-none transition-colors ${
            split.dragging
              ? "bg-green-500"
              : "bg-gray-200 hover:bg-green-400 focus-visible:bg-green-400"
          }`}
        >
          <span
            className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-10 w-1 rounded-full ${
              split.dragging ? "bg-white" : "bg-gray-400 group-hover:bg-white"
            }`}
          />
          {/* wider invisible hit area for fingers / imprecise mice */}
          <span className="absolute inset-y-0 -left-2 -right-2" />
        </div>

        {/* ── RIGHT: Cart ──
            Width is 3/7 of the layout (up from the previous fixed
            420px, ≈1/3 on a typical screen) — left panel is flex-1, so
            it naturally takes the remaining 4/7. min-w keeps the cart
            from getting crushed narrower than the old 420px on small
            windows. */}
        <div
          className="flex-shrink-0 flex flex-col bg-white overflow-hidden"
          style={{
            width: `${split.cartPct}%`,
            minWidth: 320,
            maxWidth: "calc(100% - 360px)",
          }}
        >
          <div
            className="flex-1 min-h-0 flex flex-col overflow-hidden"
            style={{ zoom: split.rightZoom }}
          >
          <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-gray-600" />
              <span className="font-bold text-gray-900 text-sm">
                Cart ({cart.length})
              </span>
            </div>
            <div className="flex items-center gap-3">
              <TextSizeControl
                label="cart"
                index={split.rightZoomIdx}
                onChange={split.setRightZoomIdx}
              />
              {cart.length > 0 && (
                <button
                  onClick={() => clearCart()}
                  className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" /> Clear
                </button>
              )}
            </div>
          </div>

          {/* Customer type */}
          <div className="px-4 py-2 border-b border-gray-100 bg-gray-50">
            <div className="flex gap-2 mb-2">
              <button
                onClick={() => setCustomerType("WALK_IN")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-semibold border transition-colors ${customerType === "WALK_IN" ? "bg-green-600 text-white border-green-600" : "bg-white text-gray-600 border-gray-200 hover:border-green-400"}`}
              >
                <User className="w-3 h-3" /> Walk-In
              </button>
              <button
                onClick={() => setCustomerType("NAMED")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-semibold border transition-colors ${customerType === "NAMED" ? "bg-green-600 text-white border-green-600" : "bg-white text-gray-600 border-gray-200 hover:border-green-400"}`}
              >
                <User className="w-3 h-3" /> Named Customer
              </button>
            </div>
            {customerType === "NAMED" && (
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Customer name"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="flex-1 border border-gray-200 px-2 py-1.5 text-xs focus:outline-none focus:border-green-400 rounded"
                />
                <input
                  type="text"
                  placeholder="Phone"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  className="w-28 border border-gray-200 px-2 py-1.5 text-xs focus:outline-none focus:border-green-400 rounded"
                />
              </div>
            )}
          </div>

          {/* Cart items */}
          <div ref={cartListRef} className="flex-1 overflow-y-auto">
            {cart.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                Cart is empty
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {cart.map((item) => (
                  <CartItemRow
                    key={`${item.product.id}-${item.variationId || "base"}`}
                    item={item}
                    onQtyChange={(qty) =>
                      updateQty(item.product.id, qty, item.variationId)
                    }
                    onDiscountChange={(d) =>
                      updateItemDiscount(item.product.id, d, item.variationId)
                    }
                    onRemove={() =>
                      setCart((p) =>
                        p.filter(
                          (i) =>
                            !(
                              i.product.id === item.product.id &&
                              i.variationId === item.variationId
                            ),
                        ),
                      )
                    }
                  />
                ))}
              </div>
            )}
          </div>

          {/* Totals */}
          <div className="border-t border-gray-200 bg-gray-50">
            {/* Discount */}
            <div className="px-4 py-2 border-b border-gray-100">
              <button
                onClick={() => setShowDiscountPanel(!showDiscountPanel)}
                className="flex items-center gap-2 text-xs font-semibold text-gray-600 hover:text-green-700"
              >
                <Tag className="w-3.5 h-3.5" /> Discount / Coupon
                <ChevronDown
                  className={`w-3 h-3 transition-transform ${showDiscountPanel ? "rotate-180" : ""}`}
                />
              </button>
              {showDiscountPanel && (
                <div className="mt-2 space-y-2">
                  {appliedDiscount ? (
                    <div className="flex items-center justify-between bg-green-100 border border-green-300 rounded px-2 py-1.5 text-xs">
                      <span className="font-bold text-green-800">
                        {appliedDiscount.code}
                      </span>
                      <button onClick={() => setAppliedDiscount(null)}>
                        <X className="w-3 h-3 text-green-700" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        placeholder="Coupon code"
                        value={couponCode}
                        onChange={(e) =>
                          setCouponCode(e.target.value.toUpperCase())
                        }
                        className="flex-1 border border-gray-300 px-2 py-1.5 text-xs focus:outline-none focus:border-green-400 rounded"
                      />
                      <button
                        onClick={handleApplyCoupon}
                        disabled={couponLoading}
                        className="px-3 py-1.5 bg-green-600 text-white text-xs font-semibold rounded hover:bg-green-700 disabled:opacity-50"
                      >
                        {couponLoading ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          "Apply"
                        )}
                      </button>
                    </div>
                  )}
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-gray-600 w-24">
                      Manual off (₦):
                    </span>
                    <input
                      type="number"
                      min={0}
                      value={manualDiscount || ""}
                      onChange={(e) =>
                        setManualDiscount(
                          Math.max(0, parseFloat(e.target.value) || 0),
                        )
                      }
                      className="flex-1 border border-gray-300 px-2 py-1.5 text-xs focus:outline-none rounded"
                      placeholder="0"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="px-4 py-3 space-y-1.5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              {totalDiscount > 0 && (
                <div className="flex justify-between text-green-700 font-medium">
                  <span>Discount</span>
                  <span>-{formatPrice(totalDiscount)}</span>
                </div>
              )}
              <div className="flex justify-between font-extrabold text-gray-900 text-lg pt-1 border-t border-gray-200">
                <span>TOTAL</span>
                <span className="text-green-700">{formatPrice(total)}</span>
              </div>
            </div>

            <div className="px-4 pb-4 space-y-2">
              <button
                onClick={() => setShowPayment(true)}
                disabled={cart.length === 0}
                className="w-full bg-amber-400 hover:bg-amber-500 disabled:opacity-40 text-gray-900 font-extrabold py-4 rounded-lg text-lg flex items-center justify-center gap-2 shadow"
              >
                <CreditCard className="w-5 h-5" /> CHARGE {formatPrice(total)}
              </button>
              {/* Suspend button — holds current cart for later */}
              <button
                onClick={() => setShowSuspendDialog(true)}
                disabled={cart.length === 0}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-semibold py-2.5 rounded-lg text-sm flex items-center justify-center gap-2"
                title="Pause this transaction and start a new one"
              >
                <PauseCircle className="w-4 h-4" /> Hold Transaction
              </button>
            </div>
          </div>
          </div>
        </div>
      </div>

      {/* ── Payment Modal ── */}
      {showPayment && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gray-900 text-white px-6 py-4 flex items-center justify-between">
              <h2 className="font-bold text-lg">Process Payment</h2>
              <button onClick={() => setShowPayment(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="text-center mb-6">
                <p className="text-sm text-gray-500">Amount Due</p>
                <p className="text-4xl font-extrabold text-green-700">
                  {formatPrice(total)}
                </p>
              </div>

              <div className="grid grid-cols-4 gap-2 mb-5">
                {(["CASH", "CARD", "TRANSFER", "SPLIT"] as PaymentMethod[]).map(
                  (m) => (
                    <button
                      key={m}
                      onClick={() => setPaymentMethod(m)}
                      className={`flex flex-col items-center gap-1 py-3 rounded-lg border-2 transition-all text-xs font-semibold ${paymentMethod === m ? "border-green-500 bg-green-50 text-green-800" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}
                    >
                      {m === "CASH" && <Banknote className="w-5 h-5" />}
                      {m === "CARD" && <CreditCard className="w-5 h-5" />}
                      {m === "TRANSFER" && (
                        <ArrowRightLeft className="w-5 h-5" />
                      )}
                      {m === "SPLIT" && <Calculator className="w-5 h-5" />}
                      {m}
                    </button>
                  ),
                )}
              </div>

              {paymentMethod === "CASH" && (
                <div className="space-y-3">
                  <input
                    type="number"
                    value={amountTendered}
                    onChange={(e) => setAmountTendered(e.target.value)}
                    placeholder={String(Math.ceil(total / 100) * 100)}
                    className="w-full border-2 border-gray-300 px-4 py-3 text-xl font-bold focus:outline-none focus:border-green-500 rounded-lg text-center"
                    autoFocus
                  />
                  <div className="flex flex-wrap gap-2">
                    {[total, ...quickAmounts.slice(0, 5)].map((amt, i) => (
                      <button
                        key={i}
                        onClick={() => setAmountTendered(String(amt))}
                        className="px-3 py-1.5 border border-gray-300 rounded text-sm font-semibold hover:border-green-500 hover:bg-green-50"
                      >
                        {i === 0 ? "Exact" : formatPrice(amt)}
                      </button>
                    ))}
                  </div>
                  {amountTendered && parseFloat(amountTendered) >= total && (
                    <div className="bg-green-100 border border-green-300 rounded-lg p-3 text-center">
                      <p className="text-sm text-green-700 font-medium">
                        Change:
                      </p>
                      <p className="text-2xl font-extrabold text-green-800">
                        {formatPrice(parseFloat(amountTendered) - total)}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {(paymentMethod === "CARD" || paymentMethod === "TRANSFER") && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center space-y-3">
                  <p className="text-sm text-blue-700 font-medium">
                    {paymentMethod === "CARD"
                      ? "💳 POS Terminal"
                      : "🏦 Bank Transfer"}
                  </p>
                  <input
                    type="text"
                    placeholder="Reference / Receipt No. (optional)"
                    value={paymentRef}
                    onChange={(e) => setPaymentRef(e.target.value)}
                    className="w-full border border-blue-200 px-3 py-2 text-sm rounded focus:outline-none focus:border-blue-400"
                  />
                </div>
              )}

              {paymentMethod === "SPLIT" && (
                <div className="space-y-3">
                  <p className="text-xs text-gray-500 text-center">
                    Remaining:{" "}
                    <strong>{formatPrice(Math.max(0, splitRemaining))}</strong>
                  </p>
                  {splitPayments.map((sp, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <select
                        value={sp.method}
                        onChange={(e) => {
                          const n = [...splitPayments];
                          n[i].method = e.target.value as any;
                          setSplitPayments(n);
                        }}
                        className="border border-gray-300 px-2 py-2 text-sm rounded focus:outline-none w-28"
                      >
                        <option value="CASH">Cash</option>
                        <option value="CARD">Card</option>
                        <option value="TRANSFER">Transfer</option>
                      </select>
                      <input
                        type="number"
                        value={sp.amount || ""}
                        onChange={(e) => {
                          const n = [...splitPayments];
                          n[i].amount = parseFloat(e.target.value) || 0;
                          setSplitPayments(n);
                        }}
                        placeholder="Amount"
                        className="flex-1 border border-gray-300 px-3 py-2 text-sm rounded focus:outline-none focus:border-green-500"
                      />
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={processPayment}
                disabled={processing}
                className="w-full mt-5 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white font-extrabold py-4 rounded-xl text-lg flex items-center justify-center gap-2"
              >
                {processing ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5" /> Confirm Payment
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Camera Barcode Scanner Modal ── */}
      {showCameraScanner && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-amber-500" />
                <span className="font-bold text-gray-900">
                  Scan Product Barcode
                </span>
              </div>
              <button onClick={stopCameraScanner}>
                <X className="w-5 h-5 text-gray-400 hover:text-gray-700" />
              </button>
            </div>

            {/* Video viewfinder */}
            <div className="relative bg-black">
              <video
                ref={videoRef}
                className="w-full"
                style={{ maxHeight: "320px", objectFit: "cover" }}
                autoPlay
                muted
                playsInline
              />
              {/* Targeting overlay */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="relative w-52 h-32">
                  {/* Corner brackets */}
                  <span className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-amber-400 rounded-tl" />
                  <span className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-amber-400 rounded-tr" />
                  <span className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-amber-400 rounded-bl" />
                  <span className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-amber-400 rounded-br" />
                  {/* Scan line animation */}
                  <div
                    className="absolute left-1 right-1 h-0.5 bg-amber-400 opacity-80"
                    style={{
                      animation: "scanline 1.8s linear infinite",
                      top: "50%",
                    }}
                  />
                </div>
              </div>
            </div>

            <div className="px-5 py-4 text-center space-y-2">
              <p className="text-sm text-gray-600">
                Point the camera at the product barcode or QR code
              </p>
              <p className="text-xs text-gray-400">
                Supports EAN-13, EAN-8, Code128, QR Code, and more
              </p>
              <button
                onClick={stopCameraScanner}
                className="mt-2 px-5 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </div>

          {/* Scanline keyframe animation injected inline */}
          <style>{`
            @keyframes scanline {
              0%   { top: 10%; }
              50%  { top: 90%; }
              100% { top: 10%; }
            }
          `}</style>
        </div>
      )}

      {/* ── Receipt Modal ── */}
      {showReceipt && completedOrder && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-bold text-gray-900">
                  Payment Successful!
                </span>
              </div>
              <button onClick={() => setShowReceipt(false)}>
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>
            <div id="receipt-content" className="p-5 font-mono text-xs">
              <div className="text-center mb-3">
                <p className="font-bold text-base">NigitTriple Supermarket</p>
                <p className="text-gray-500">
                  30, Abuloma Road (Bozgomero Estate)
                </p>
                <p className="text-gray-500">Port Harcourt, Rivers State</p>
                <p className="text-gray-500">Tel: +234 916 977 6138</p>
                <div className="border-t border-dashed border-gray-300 my-2" />
                <p className="text-gray-600">
                  Receipt #{completedOrder.receiptNumber}
                </p>
                <p className="text-gray-600">
                  {completedOrder.processedAt.toLocaleString("en-NG")}
                </p>
                {completedOrder.customerName && (
                  <p className="text-gray-600">
                    Customer: {completedOrder.customerName}
                  </p>
                )}
                <div className="border-t border-dashed border-gray-300 my-2" />
              </div>
              <div className="space-y-1 mb-3">
                {completedOrder.items.map((item, i) => {
                  const isScalableItem = !!item.product.isScalable;
                  const itemUnit = item.product.scaleUnit || "unit";
                  const qtyLabel = isScalableItem
                    ? `${formatScaleQty(item.quantity, item.product.scaleStep)} ${itemUnit}`
                    : String(item.quantity);
                  const priceLabel = isScalableItem
                    ? `${formatPrice(item.unitPrice)}/${itemUnit}`
                    : formatPrice(item.unitPrice);
                  return (
                    <div key={i}>
                      <div className="flex justify-between">
                        <span className="flex-1 pr-2 truncate">
                          {item.product.name}
                        </span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                        <span>
                          {qtyLabel} × {priceLabel}
                          {item.discount > 0 && ` (-${item.discount}%)`}
                        </span>
                        <span>
                          {formatPrice(
                            item.unitPrice *
                              item.quantity *
                              (1 - item.discount / 100),
                          )}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="border-t border-dashed border-gray-300 pt-2 space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{formatPrice(completedOrder.subtotal)}</span>
                </div>
                {completedOrder.discountAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Discount</span>
                    <span>-{formatPrice(completedOrder.discountAmount)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold border-t border-dashed border-gray-300 pt-1">
                  <span>TOTAL</span>
                  <span>{formatPrice(completedOrder.total)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment: {completedOrder.paymentMethod}</span>
                </div>
                {completedOrder.amountTendered !== undefined && (
                  <div className="flex justify-between">
                    <span>Tendered</span>
                    <span>{formatPrice(completedOrder.amountTendered)}</span>
                  </div>
                )}
                {completedOrder.changeGiven !== undefined &&
                  completedOrder.changeGiven > 0 && (
                    <div className="flex justify-between font-bold">
                      <span>CHANGE</span>
                      <span>{formatPrice(completedOrder.changeGiven)}</span>
                    </div>
                  )}
              </div>
              <div className="border-t border-dashed border-gray-300 mt-3 pt-2 text-center text-gray-500">
                <p>Thank you for shopping!</p>
                <p className="text-gray-400 text-[10px] mt-2">
                  Software by Calstins Ltd · calstins.com
                </p>
              </div>
            </div>
            <div className="p-4 border-t flex gap-3">
              <button
                onClick={() => printCurrentReceipt()}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-gray-900 text-white font-bold rounded-lg hover:bg-gray-800"
              >
                <Printer className="w-4 h-4" /> Print
              </button>
              <button
                onClick={() => setShowReceipt(false)}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700"
              >
                <ShoppingCart className="w-4 h-4" /> New Sale
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Suspend Dialog ── */}
      {showSuspendDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden">
            <div className="bg-blue-700 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PauseCircle className="w-5 h-5" />
                <h2 className="font-bold text-lg">Hold Transaction</h2>
              </div>
              <button onClick={() => setShowSuspendDialog(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-sm text-gray-600">
                This will pause the current transaction ({cart.length} item
                {cart.length !== 1 ? "s" : ""}, {formatPrice(total)}) and let
                you serve another customer. You can resume it at any time from
                the <strong>Held</strong> queue.
              </p>
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">
                  Optional note (e.g. "Customer checking wallet")
                </label>
                <input
                  type="text"
                  value={suspendLabel}
                  onChange={(e) => setSuspendLabel(e.target.value)}
                  placeholder="Leave blank if not needed"
                  className="w-full border border-gray-300 px-3 py-2 text-sm rounded focus:outline-none focus:border-blue-500"
                  onKeyDown={(e) => e.key === "Enter" && handleSuspend()}
                  autoFocus
                />
              </div>
              <button
                onClick={handleSuspend}
                disabled={suspending}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
              >
                {suspending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <PauseCircle className="w-4 h-4" />
                )}
                Hold Transaction
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Suspended Orders Panel ── */}
      {showSuspendPanel && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="bg-blue-700 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PauseCircle className="w-5 h-5" />
                <h2 className="font-bold text-lg">
                  Held Transactions ({suspendedOrders.length})
                </h2>
              </div>
              <button onClick={() => setShowSuspendPanel(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 max-h-[70vh] overflow-y-auto">
              {suspendedOrders.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <PauseCircle className="w-12 h-12 mx-auto mb-3 text-gray-200" />
                  <p className="text-sm">No held transactions</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {suspendedOrders.map((order) => (
                    <div
                      key={order.id}
                      className="border border-blue-200 rounded-lg p-4 bg-blue-50"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-gray-900 text-sm">
                            {order.posOrderNumber}
                          </p>
                          {order.suspendLabel && (
                            <p className="text-xs text-blue-700 font-medium mt-0.5">
                              📝 {order.suspendLabel}
                            </p>
                          )}
                          {order.customerName &&
                            order.customerName !== "Walk-In Customer" && (
                              <p className="text-xs text-gray-600 mt-0.5">
                                👤 {order.customerName}
                              </p>
                            )}
                          <p className="text-xs text-gray-500 mt-1">
                            {order.items.length} item
                            {order.items.length !== 1 ? "s" : ""} ·{" "}
                            <span className="font-semibold text-gray-900">
                              {formatPrice(order.total)}
                            </span>
                          </p>
                          <p className="text-[10px] text-gray-400 mt-0.5">
                            Held at{" "}
                            {new Date(order.suspendedAt).toLocaleTimeString(
                              "en-NG",
                              { hour: "2-digit", minute: "2-digit" },
                            )}
                          </p>
                          {/* Item mini-list */}
                          <ul className="mt-2 space-y-0.5">
                            {order.items.slice(0, 3).map((item) => (
                              <li
                                key={item.id}
                                className="text-[10px] text-gray-600 truncate"
                              >
                                • {item.productName} ×{item.quantity}
                              </li>
                            ))}
                            {order.items.length > 3 && (
                              <li className="text-[10px] text-gray-400">
                                + {order.items.length - 3} more
                              </li>
                            )}
                          </ul>
                        </div>
                        <div className="flex-shrink-0 flex flex-col gap-1.5">
                          <button
                            onClick={() => handleResume(order)}
                            disabled={!!resuming || cart.length > 0}
                            className="flex items-center gap-1.5 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg"
                            title={
                              cart.length > 0
                                ? "Clear or hold current cart first"
                                : "Resume this transaction"
                            }
                          >
                            {resuming === order.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <PlayCircle className="w-3.5 h-3.5" />
                            )}
                            Resume
                          </button>
                          <button
                            onClick={() => handleDeleteSuspended(order)}
                            disabled={!!deletingSuspended}
                            className="flex items-center gap-1.5 px-4 py-2 bg-red-50 hover:bg-red-100 disabled:opacity-50 text-red-700 text-xs font-bold rounded-lg border border-red-200"
                            title="Delete this held transaction"
                          >
                            {deletingSuspended === order.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="w-3.5 h-3.5" />
                            )}
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {cart.length > 0 && suspendedOrders.length > 0 && (
                <p className="mt-3 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded p-2">
                  ⚠️ You have an active cart. Hold or clear it before resuming a
                  transaction.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Close Session Modal ── */}
      {showCloseSession && session && (
        <CloseSessionModal
          session={session}
          onClose={() => setShowCloseSession(false)}
          onClosed={() => {
            setSession(null);
            setShowCloseSession(false);
          }}
        />
      )}
    </div>
  );
}